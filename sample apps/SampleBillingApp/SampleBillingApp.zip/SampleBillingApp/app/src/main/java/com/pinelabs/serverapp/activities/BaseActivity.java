package com.pinelabs.serverapp.activities;

/*
 * Created by Kushaal Singla on 5/9/2018.
 */

import android.support.v7.app.AppCompatActivity;
import android.widget.Toast;

public abstract class BaseActivity extends AppCompatActivity {
    protected void showMsg(String msg, int duration) {
        Toast.makeText(this, msg, duration).show();
    }
}
