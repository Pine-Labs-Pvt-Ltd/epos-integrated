package com.pinelabs.serverapp.activities;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.google.gson.Gson;
import com.pinelabs.serverapp.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;

public class ClientCodeDebugActivity extends BaseActivity {
    private boolean isBound;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_client_code_debug);

    }

    public void onClickClient(View view) {
        readyToPineLabs();
    }

    private void readyToPineLabs() {
        if (isBound) {
            unbindService(connection);
        }
        Intent intent = new Intent();
        intent.setAction("com.pinelabs.masterapp.SERVER");
        intent.setPackage("com.pinelabs.masterapp");
        bindService(intent, connection, Context.BIND_AUTO_CREATE);
    }

    private ServiceConnection connection = new ServiceConnection() {
        Messenger mServerMessenger;

        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            mServerMessenger = new Messenger(service);
            isBound = true;
            Message message = Message.obtain(null, 1001);

            int pasia = 100;
            int totalFine = 10000;
            Bundle data = new Bundle();

            Gson gson = new Gson();
            HashMap map = new HashMap<>();
            map.put("ApplicationId", "");
            map.put("UserId", "1234");
            map.put("MethodId", "1004");
            map.put("VersionNo", "1.0");

            HashMap map1 = new HashMap<>();
            map1.put("TransactionType", "");
            map1.put("BillingRefNo", "123456789");
            map1.put("PaymentAmount", totalFine);


            HashMap<String, HashMap> h1 = new HashMap<>();
            h1.put("Header", map);
            h1.put("Detail", map1);


            Log.e("tag", gson.toJson(h1));
            //String value = { "Header": { "ApplicationId": "abcdefgh",  "UserId": "user1234",  "MethodId": "1004",  "VersionNo": "1.0"} }";

            data.putString("MASTERAPPREQUEST", gson.toJson(h1));

            message.setData(data);

            try {
                message.replyTo = new Messenger(new IncomingHandler());
                mServerMessenger.send(message);

            } catch (RemoteException e) {
                e.printStackTrace();
            }

        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            mServerMessenger = null;
            isBound = false;
        }
    };


    //for handler the respoce of pinlab--
    private class IncomingHandler extends Handler {

        @Override
        public void handleMessage(Message msg) {
            Bundle bundle = msg.getData();
            String value = bundle.getString("MASTERAPPRESPONSE"); // process the response Json as required.

            Log.e("Tagresponse", value);
            //    Toast.makeText(SubmitChallan.this,value,Toast.LENGTH_LONG).show();

            try {
                JSONObject jsonAll = new JSONObject(value);
                JSONObject jsonRes = jsonAll.optJSONObject("Response");
                String stResMsg = jsonRes.optString("ResponseMsg");
                String stResCode = jsonRes.optString("ResponseCode");

               /* JSONObject jsonDetail=jsonAll.optJSONObject("Detail");
                String stDetInvoiceNo    = jsonDetail.optString("InvoiceNumber");
                String stDetBatchNo      = jsonDetail.optString("BatchNumber");*/

//                if (stResMsg.equalsIgnoreCase("APPROVED")) {
//                    if (isTwoChallanEnable) {
//                        updateTwoChallanPayment("Card", false);
//                    } else {
//                        makePayment(challanDetails, "Card", false);
//                    }
//                } else {
//                    Toast.makeText(SubmitChallan.this, "Payment Failed! Please retry", Toast.LENGTH_LONG).show();
//                }
                Toast.makeText(ClientCodeDebugActivity.this, "Payment Success! Please retry", Toast.LENGTH_LONG).show();
            } catch (JSONException e) {
                e.printStackTrace();
                Toast.makeText(ClientCodeDebugActivity.this, "Payment Failed! Please retry", Toast.LENGTH_LONG).show();
            }
        }

    }
}
