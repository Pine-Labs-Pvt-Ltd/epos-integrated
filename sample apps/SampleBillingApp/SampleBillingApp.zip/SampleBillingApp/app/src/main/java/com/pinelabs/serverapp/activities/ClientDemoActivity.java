package com.pinelabs.serverapp.activities;

/*
 * Created by Kushaal Singla on 4/3/2018.
 */

import android.annotation.SuppressLint;
import android.content.ComponentName;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.ServiceConnection;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.pinelabs.serverapp.R;
import com.pinelabs.serverapp.beans.beans.PromoContentLocal;
import com.pinelabs.serverapp.beans.requests.AdsLogBean;
import com.pinelabs.serverapp.beans.requests.BaseRequest;
import com.pinelabs.serverapp.beans.requests.DoTransactionRequest;
import com.pinelabs.serverapp.beans.requests.GetAdRequest;
import com.pinelabs.serverapp.beans.requests.HeaderRequest;
import com.pinelabs.serverapp.beans.requests.LaunchAppRequest;
import com.pinelabs.serverapp.beans.requests.LogAdRequest;
import com.pinelabs.serverapp.beans.requests.PrintData;
import com.pinelabs.serverapp.beans.requests.PrintRequest;
import com.pinelabs.serverapp.beans.responses.BaseResponse;
import com.pinelabs.serverapp.beans.responses.DetailResponse;
import com.pinelabs.serverapp.config.AppConfig;
import com.pinelabs.serverapp.enums.BillingMethodId;
import com.pinelabs.serverapp.enums.MsgType;
import com.pinelabs.serverapp.enums.OperationType;
import com.pinelabs.serverapp.enums.PeripheralOperationType;
import com.pinelabs.serverapp.enums.PlutusOperationType;
import com.pinelabs.serverapp.enums.TransactionType;
import com.pinelabs.serverapp.utils.GsonUtils;
import com.pinelabs.serverapp.utils.PlutusUtils;

import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class ClientDemoActivity extends BaseActivity {
    private static final int MASTER_APP = 2;
    private static final int BILLING_APP = 1001;
    private final String TAG = ClientDemoActivity.class.getSimpleName();
    private Messenger mServerMessenger;
    private Messenger mClientMessenger;
    private boolean isBound;
    private LinearLayout mRootView;
    private String msg;

    private ServiceConnection connection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            Toast.makeText(ClientDemoActivity.this, "Service is Connected, Try Now!!", Toast.LENGTH_SHORT).show();
            mServerMessenger = new Messenger(service);
            isBound = true;
            msg = name.getClassName();
            try {
                linkToDeath(service);
            } catch (RemoteException e) {
                e.printStackTrace();
            }
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            mServerMessenger = null;
            isBound = false;
        }

        private void linkToDeath(IBinder service) throws RemoteException {
            service.linkToDeath(new IBinder.DeathRecipient() {
                @Override
                public void binderDied() {
                    Log.d(TAG, "Device service is dead. Reconnecting...");
                    onClickStart(null);
                }
            }, 0);
        }

    };


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //Uri uri = Uri.parse("MasterApp_content://com.pinelabs.masterapp/shared_images/BGF_A_20.png");
        setContentView(R.layout.activity_service_demo);
        ImageView ivTest = findViewById(R.id.iv_test);

        File file = new File("/storage/emulated/0/Android/data/com.pinelabs.masterapp/files/campaigns/resourceId=20180525cf44cdb5-e3e4-4309-8268-6d0e0bb4bdd5");
        if (file.exists()) {
            //Toast.makeText(ClientDemoActivity.this, "Yessssss", Toast.LENGTH_SHORT).show();
            Bitmap bitmap = BitmapFactory.decodeFile(file.getAbsolutePath());
            ivTest.setImageBitmap(bitmap);
        } else {
            //Toast.makeText(ClientDemoActivity.this, "NOOOO", Toast.LENGTH_SHORT).show();
        }

        //Init Thread for incoming responses
        HandlerThread thread = new HandlerThread("ClientThread");
        thread.start();
        mClientMessenger = new Messenger(new IncomingHandler(thread));

        mRootView = findViewById(R.id.root_view);

        addAllButtons();
    }

    private void addAllButtons() {

        for (final TransactionType type : TransactionType.values()) {
            View view = LayoutInflater.from(this).inflate(R.layout.view_btn, mRootView, false);
            Button button = view.findViewById(R.id.my_btn);
            if (button != null) {
                button.setText(type.toString());
                button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        HeaderRequest<DoTransactionRequest> headerRequest = type.getRequest();
                        if (headerRequest == null) {
                            onClickSaleTxn(type.getValue());
                        } else {
                            DoTransactionRequest request = headerRequest.getDetail();
                            if (request.getInvoiceNo() == null && request.getTransactionLogId() == null) {
                                onClickSaleTxn(headerRequest);
                            } else {
                                showEnterDialog(request, headerRequest);
                            }
                        }
                    }
                });
                mRootView.addView(view);
            }
        }

        for (final OperationType type : OperationType.values()) {
            View view = LayoutInflater.from(this).inflate(R.layout.view_btn, mRootView, false);
            Button button = view.findViewById(R.id.my_btn);
            if (button != null) {
                button.setText(type.toString());
                button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String value = new BaseRequest(type.getValue()).toString();
                        sendMessage(ClientDemoActivity.MASTER_APP, value);
                    }
                });

                mRootView.addView(view);
            }
        }
        for (final PlutusOperationType type : PlutusOperationType.values()) {
            View view = LayoutInflater.from(this).inflate(R.layout.view_btn, mRootView, false);
            Button button = view.findViewById(R.id.my_btn);
            if (button != null) {
                button.setText(type.toString());
                button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String value = new BaseRequest(type.getValue()).toString();

                        byte[] sourceId = new byte[]{0x12, 0x12};
                        byte[] bytes = PlutusUtils.GetTransmissionPacketForCentral(sourceId, type.getValue(), value);

                        sendMessagePlutus(ClientDemoActivity.MASTER_APP, bytes);
                    }
                });

                mRootView.addView(view);
            }
        }
    }

    public void onCreditDebitClick(@MsgType.What int what, byte[] value){
        if (isBound && mServerMessenger != null) {
            Message message = Message.obtain(null, what);
            Bundle data = new Bundle();
            data.putByteArray(AppConfig.PLUTUS_REQUEST_KEY, value);
            message.setData(data);
            try {
                message.replyTo = mClientMessenger;
                mServerMessenger.send(message);

            } catch (RemoteException e) {
                e.printStackTrace();
            }
        } else {
            Toast.makeText(this, "Service is not Connected", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Invoke Server Service
     */
    public void onClickStart(View view) {
        if (isBound) {
            showMsg("Already Started: " + msg, Toast.LENGTH_LONG);
        } else {
            Intent intent = new Intent();
            intent.setAction("com.pinelabs.masterapp.SERVER");
            intent.setPackage("com.pinelabs.masterapp");
            bindService(intent, connection, BIND_AUTO_CREATE);
        }
    }

    public void onClickConnectEMI(View view) {
        if (isBound) {
            showMsg("Already Started" + msg, Toast.LENGTH_LONG);
        } else {
            Intent intent = new Intent();
            intent.setAction("com.pinelabs.emi.SERVER");
            intent.setPackage("com.pinelabs.serverapp");
            bindService(intent, connection, BIND_AUTO_CREATE);
        }
    }

    public void onClickConnectPlutus(View view) {
        if (isBound) {
            showMsg("Already Started" + msg, Toast.LENGTH_LONG);
        } else {
            Intent intent = new Intent();
            intent.setAction("com.pinelabs.plutusplus.SERVER");
            intent.setPackage("com.pinelabs.serverapp");
            bindService(intent, connection, BIND_AUTO_CREATE);
        }
    }

    public void onClickConnectPeripheral(View view) {
        Intent intent = new Intent();
        intent.setAction("com.pinelabs.peripheralappservice.ACTION_BIND");
        intent.setPackage("com.pinelabs.peripheralappservice");
        bindService(intent, connection, BIND_AUTO_CREATE);
    }

    private void sendMessagePlutus(@MsgType.What int what, byte[] value) {
        if (isBound && mServerMessenger != null) {
            Message message = Message.obtain(null, what);
            Bundle data = new Bundle();
            data.putByteArray(AppConfig.PLUTUS_REQUEST_KEY, value);
            message.setData(data);
            try {
                message.replyTo = mClientMessenger;
                mServerMessenger.send(message);

            } catch (RemoteException e) {
                e.printStackTrace();
            }
        } else {
            Toast.makeText(this, "Service is not Connected", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Call API for Operation
     */
    private void sendMessage(int what, String value) {
        sendMessage(what, value, AppConfig.REQUEST_KEY);
    }

    private void sendMessage(@MsgType.What final int what, final String value, final String key) {
        if (isBound && mServerMessenger != null) {
            Message message = Message.obtain(null, what);
            Bundle data = new Bundle();
            data.putString(key, value);
            message.setData(data);
            try {
                message.replyTo = mClientMessenger;
                mServerMessenger.send(message);

            } catch (RemoteException e) {
                e.printStackTrace();
            }
        } else {
            Toast.makeText(this, "Service is not Connected", Toast.LENGTH_SHORT).show();
        }
    }

    public void onClickLaunchMasterApp(View view) {
        String value = new LaunchAppRequest(OperationType.LAUNCH_APP.getValue()).toString();
        sendMessage(ClientDemoActivity.MASTER_APP, value);
    }

    public void onClickLaunchMasterAppWithFB(View view) {
        String csv = "\"TX12345678\",\"00\",\"APPROVED\",\"463237******1635\",\"XXXX\",\"KUSHAAL SINGLA MR\",\"VISA\",65,11,\"25805201\",0,\"PROCESSED\",\"ICICI BANK\",\"               \",\"000000000020\",2,1,\"LOVE COMMUNICATION\",\"JANAKPURI\",\"NEW DELHI    DEL       \",\"Plutus v2.12 MT ICICI BANK\",02,\"\",\"\",\"\",\"\",\"\",\"\",\"\",\"\",\"\",\"06112018\",\"165927\",\"1022280325\",\"10000\",\"0\",\"CARD_CHIP\"";
        String value = new LaunchAppRequest(OperationType.LAUNCH_APP.getValue()).toString();
        sendMessage(ClientDemoActivity.MASTER_APP, value);
    }

    public void onClickGetAppStatus(View view) {
        String value = new BaseRequest(OperationType.GET_APP_STATUS.getValue()).toString();
        sendMessage(ClientDemoActivity.MASTER_APP, value);
    }

    private String decodePlutusResponse(byte[] byteArray) {
        StringBuilder s = new StringBuilder();
        try {
            byte opType = byteArray[3];
            PlutusOperationType type = PlutusOperationType.getOpType(opType);
            String s1 = new String(byteArray, "UTF-8");
            return type + "|" + s1;
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return s.toString();
    }

    public void onClickGetAdContent(View view) {

       /* GetAdRequest request = new GetAdRequest(1001);
        request.setAppId("PLUTUS_APP");
        request.setReqRefId("5678");
        request.setUserId("1234");
        request.setScreenId("1018");*/


        GetAdRequest request = new GetAdRequest(1001);
        request.setAppId("PLUTUSPLUS_APP");
        request.setReqRefId("5678");
        request.setUserId("1234");
        request.setScreenId("PIN_ENTRY");

        //LoggerUtils.log(JsonUtils.fromJsonToString(request));


        String value = GsonUtils.fromJsonToString(request);

        sendMessage(ClientDemoActivity.MASTER_APP, value);
    }

    public void onClickLogAdContent(View view) {
        LogAdRequest logAdRequest = new LogAdRequest(1002);

        List<AdsLogBean> list = new ArrayList<>();

        AdsLogBean adsLogBean = new AdsLogBean();
        adsLogBean.setReqRefId(String.valueOf(System.currentTimeMillis()));
        adsLogBean.setScreenId("Test screen 1");
        adsLogBean.setAppId("1001");
        adsLogBean.setStartDateTime(System.currentTimeMillis());

        PromoContentLocal promoContentLocal = new PromoContentLocal();
        promoContentLocal.setCampaignId("343");
        promoContentLocal.setContentAutoPlay(true);
        promoContentLocal.setContentTypeId(2);
        adsLogBean.setAdditionalInfo(GsonUtils.fromJsonToString(promoContentLocal));

        list.add(adsLogBean);

        adsLogBean = new AdsLogBean();
        adsLogBean.setReqRefId(String.valueOf(System.currentTimeMillis()));
        adsLogBean.setScreenId("Test screen 2");
        adsLogBean.setAppId("1001");
        adsLogBean.setStartDateTime(System.currentTimeMillis());
        adsLogBean.setAdditionalInfo("Test string 2");


        list.add(adsLogBean);

        logAdRequest.setAdLogs(list);

        String value = GsonUtils.fromJsonToString(logAdRequest);
        sendMessage(ClientDemoActivity.MASTER_APP, value);
    }

    public void onClickSaleTxn(Long transactionType) {
        DoTransactionRequest request = new DoTransactionRequest(transactionType);
        request.setBillingRefNo("TX12345678");
        request.setPaymentAmount(20000L);
        request.setBankCode("2020");
        request.setCardNumber("XXXX 1234 XXXX");
        request.setExpiry("March 2020");
        request.setInvoiceNo(432004L);
        request.setSwipe(true);
        request.setField0("sample");
        request.setField1("sample");
        request.setField2("sample");
        request.setField3("sample");
        request.setBatchNo(102);
        request.setRoc(101);
        request.setTransactionLogId(545L);
        request.setRewardAmount(10000L);
        request.setCustomerMobileNumber("8800000000");
        request.setCustomerEmailId("customer@xyz.com");
        request.setConsentCustomerMobile(false);
        request.setConsentCustomerEmailId(true);
        request.setMerchantMobileNumber("9900000000");
        request.setMerchantEmailId("merchant@xyz.com");
        request.setConsentMerchantMobile(false);
        request.setConsentCustomerEmailId(true);
        request.setWalletProgramId(300L);

        HeaderRequest<DoTransactionRequest> headerRequest = new HeaderRequest<>(BillingMethodId.DO_TRANSACTION.getValue());
        headerRequest.setDetail(request);
        onClickSaleTxn(headerRequest);
    }

    public void onClickSaleTxn(final HeaderRequest request) {
        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View view = LayoutInflater.from(this).inflate(R.layout.layout_edit, null, false);
        builder.setView(view);
        final EditText etRequest = view.findViewById(R.id.et_request);
        Button btnSubmit = view.findViewById(R.id.btn_submit);
        etRequest.setText(request.toString());

        final AlertDialog alertDialog = builder.create();

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s = request.toString();
                if (isValid(s)) {
                    sendMessage(ClientDemoActivity.BILLING_APP, etRequest.getText().toString());
                    alertDialog.dismiss();
                }
            }
        });
        alertDialog.show();
    }

    private boolean isValid(String msg) {
        boolean result;
        try {
            new JSONObject(msg);
            result = true;
        } catch (Exception e) {
            result = false;
            e.printStackTrace();
        }
        return result;
    }

    public void onClickPrint(View view) {
        print("PrintData API will be called ThirdPartyApp wants to print data with our service.");
  /*      PrintRequest printRequest = new PrintRequest(PeripheralOperationType.PRINT.getValue());
        List<PrintData> list = new ArrayList<>();

        PrintData data = new PrintData();
        data.setiPrintDataType(0);
        data.setiPrinterWidth(24);
        data.setCenterAligned(true);
        data.setStrDataToPrint("PrintData API will be called ThirdPartyApp wants to print data with our service.");

        list.add(data);
        printRequest.setData(GsonUtils.fromJsonToString(list));

        String value = GsonUtils.fromJsonToString(printRequest);
        sendMessage(ClientDemoActivity.BILLING_APP, value, AppConfig.THIRD_PARTY_REQUEST_KEY);*/
    }

    private void print(String data) {
        PrintRequest printRequest = new PrintRequest(OperationType.PRINT_TXN.getValue());
        List<PrintData> list = new ArrayList<>();
        list.add(new PrintData().setStrDataToPrint(data));
        printRequest.setData(list);
        HeaderRequest<PrintRequest> headerRequest = new HeaderRequest<>(BillingMethodId.PRINT.getValue());
        headerRequest.setDetail(printRequest);
        sendMessage(ClientDemoActivity.BILLING_APP, headerRequest.toString());
    }

    public void onClickSaleManual(View view) {
        HeaderRequest<DoTransactionRequest> headerRequest = new HeaderRequest<>(BillingMethodId.DO_TRANSACTION.getValue());
        headerRequest.setDetail(new DoTransactionRequest(
                4001L).setBillingRefNo("TX12345678").setPaymentAmount(9900L).setBankCode("01").setCardNumber("4213280123546148")
                .setExpiry("1013").setSwipe(false));
        onClickSaleTxn(headerRequest);
    }

    private void showDialog(final String value, final boolean print) {
        AlertDialog.Builder builder;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            builder = new AlertDialog.Builder(ClientDemoActivity.this, android.R.style.Theme_Holo_Dialog_NoActionBar);
        } else {
            builder = new AlertDialog.Builder(ClientDemoActivity.this);
        }
        if (print) {
            builder.setNegativeButton("Print", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    print(value);
                }
            });
        }
        builder.setTitle("Result")
                .setMessage(value)
                .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {

                    }
                })
                .setIcon(android.R.drawable.ic_dialog_alert)
                .show();
    }

    private void showEnterDialog(final DoTransactionRequest request, final HeaderRequest headerRequest) {
        final AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);
        LayoutInflater inflater = this.getLayoutInflater();

        final View dialogView = inflater.inflate(R.layout.popup_enter, null);
        dialogBuilder.setView(dialogView);

        final AlertDialog b = dialogBuilder.create();

        b.setCancelable(false);
        b.setCanceledOnTouchOutside(false);

        final EditText etInvoice = dialogView.findViewById(R.id.et_invoice);
        final EditText etLogId = dialogView.findViewById(R.id.et_log_id);
        Button btnSubmit = dialogView.findViewById(R.id.btn_submit);

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!TextUtils.isEmpty(etInvoice.getText())) {
                    request.setInvoiceNo(Long.valueOf(etInvoice.getText().toString()));
                } else {
                    request.setInvoiceNo(null);
                }
                if (!TextUtils.isEmpty(etLogId.getText())) {
                    request.setTransactionLogId(Long.valueOf(etLogId.getText().toString()));
                } else {
                    request.setTransactionLogId(null);
                }
                onClickSaleTxn(headerRequest);
                b.dismiss();
            }
        });

        b.show();
    }

    public void onClickConfig(View view) {
        HeaderRequest<DoTransactionRequest> headerRequest = new HeaderRequest<>(BillingMethodId.CONFIGURATION.getValue());
        sendMessage(ClientDemoActivity.BILLING_APP, headerRequest.toString());
    }

    /**
     * Handler of incoming messages from service.
     */
    @SuppressLint("HandlerLeak")
    private class IncomingHandler extends Handler {

        IncomingHandler(HandlerThread thr) {
            super(thr.getLooper());
        }

        @Override
        public void handleMessage(Message msg) {
            //Toast.makeText(ClientDemoActivity.this, "Reply Rx: " + msg.what, Toast.LENGTH_SHORT).show();
            Bundle bundle;
            String value;
            switch (msg.what) {
                case ClientDemoActivity.MASTER_APP:
                    bundle = msg.getData();
                    value = bundle.getString(AppConfig.RESPONSE_KEY);
                    if (TextUtils.isEmpty(value)) {
                        value = decodePlutusResponse(bundle.getByteArray(AppConfig.PLUTUS_RESPONSE_KEY));
                    }

                    BaseResponse response = GsonUtils.fromStringToJson(value, BaseResponse.class);
                    boolean print = false;
                    if (response != null) {
                        value = response.getResponseMessage();
                        if (response.getOperationType() == PeripheralOperationType.SALE.getValue()) {
                            print = true;
                        }
                    }

                    Log.d("kush byte value", value + "");
                    showDialog(value, print);
                    //Toast.makeText(ClientDemoActivity.this, value, Toast.LENGTH_LONG).show();
                    break;
                case ClientDemoActivity.BILLING_APP:
                    bundle = msg.getData();
                    value = bundle.getString(AppConfig.RESPONSE_KEY);
                    DetailResponse detailResponse = GsonUtils.fromStringToJson(value, DetailResponse.class);
                    if (detailResponse != null) {
                        showDialog(value, true);
                    }
                    break;
                default:
                    super.handleMessage(msg);
                    break;
            }
        }
    }
}
