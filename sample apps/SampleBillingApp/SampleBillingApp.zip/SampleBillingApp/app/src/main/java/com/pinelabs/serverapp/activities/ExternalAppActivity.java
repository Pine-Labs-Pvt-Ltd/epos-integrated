package com.pinelabs.serverapp.activities;

/*
 * Created by Kushaal Singla on 4/3/2018.
 */

import android.annotation.SuppressLint;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.Toast;

import com.pinelabs.serverapp.BuildConfig;
import com.pinelabs.serverapp.R;
import com.pinelabs.serverapp.beans.requests.BluetoothRequest;
import com.pinelabs.serverapp.beans.requests.DoTransactionRequest;
import com.pinelabs.serverapp.beans.requests.EposTransactionType;
import com.pinelabs.serverapp.beans.requests.HeaderRequest;
import com.pinelabs.serverapp.beans.requests.InvoiceRequest;
import com.pinelabs.serverapp.beans.requests.PrintData;
import com.pinelabs.serverapp.beans.requests.PrintRequest;
import com.pinelabs.serverapp.beans.responses.BaseResponse;
import com.pinelabs.serverapp.beans.responses.DetailResponse;
import com.pinelabs.serverapp.config.AppConfig;
import com.pinelabs.serverapp.enums.BillingMethodId;
import com.pinelabs.serverapp.enums.MsgType;
import com.pinelabs.serverapp.enums.OperationType;
import com.pinelabs.serverapp.enums.PeripheralOperationType;
import com.pinelabs.serverapp.enums.PlutusOperationType;
import com.pinelabs.serverapp.enums.TransactionType;
import com.pinelabs.serverapp.utils.GsonUtils;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class ExternalAppActivity extends BaseActivity {
    private static final int MASTER_APP = 2;
    private static final int BILLING_APP = 1001;
    private static String TARGET_PACKAGE_NAME = "com.pinelabs.masterapp";
    private final String TAG = ExternalAppActivity.class.getSimpleName();
    private Messenger mServerMessenger;
    private Messenger mClientMessenger;
    private boolean isBound;
    private LinearLayout mRootView;
    private Switch swePOS;
    private String msg;
    private BroadcastReceiver hybridReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String msg= intent.getStringExtra("HYBRID_RESPONSE");
            showMsg(msg,Toast.LENGTH_LONG);
        }
    };

    private ServiceConnection connection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            Toast.makeText(ExternalAppActivity.this, "Service is Connected, Try Now!!", Toast.LENGTH_SHORT).show();
            mServerMessenger = new Messenger(service);
            isBound = true;
            msg = name.getClassName();
            try {
                linkToDeath(service);
            } catch (RemoteException e) {
                e.printStackTrace();
            }
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            mServerMessenger = null;
            isBound = false;
        }

        private void linkToDeath(IBinder service) throws RemoteException {
            service.linkToDeath(new IBinder.DeathRecipient() {
                @Override
                public void binderDied() {
                    Log.d(TAG, "Device service is dead. Reconnecting...");
                    onClickStart(null);
                }
            }, 0);
        }

    };


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //Uri uri = Uri.parse("MasterApp_content://com.pinelabs.masterapp/shared_images/BGF_A_20.png");
        setContentView(R.layout.activity_external_app);
        //Init Thread for incoming responses
        HandlerThread thread = new HandlerThread("ClientThread");
        thread.start();

        mClientMessenger = new Messenger(new IncomingHandler(thread));
        registerReceiver(hybridReceiver,new IntentFilter("com.pinelabs.HYBRID_RESPONSE"));
        mRootView = findViewById(R.id.root_view);
        initViews();
        addAllButtons();
        onClickStart(null);
    }

    private void initViews() {
        swePOS = findViewById(R.id.sw_epos);
        swePOS.setChecked(TARGET_PACKAGE_NAME.equalsIgnoreCase("com.pinelabs.epos"));
        swePOS.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    TARGET_PACKAGE_NAME = "com.pinelabs.epos";
                } else {
                    TARGET_PACKAGE_NAME = "com.pinelabs.masterapp";
                }
                if (isBound) {
                    unbindService(connection);
                    isBound = false;
                }
                onClickStart(null);
            }
        });
        swePOS.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                Toast.makeText(ExternalAppActivity.this, TARGET_PACKAGE_NAME, Toast.LENGTH_SHORT).show();
                return true;
            }
        });
    }

    private void addAllButtons() {
        if (BuildConfig.IS_EPOS){
            for(final EposTransactionType type:EposTransactionType.values()){
                View view = LayoutInflater.from(this).inflate(R.layout.view_btn, mRootView, false);
                Button button = view.findViewById(R.id.my_btn);
                if (button != null) {
                    button.setText(type.toString());
                    button.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            HeaderRequest<DoTransactionRequest> headerRequest = type.getRequest();
                            if (headerRequest == null) {
                                onClickSaleTxn(type.getValue());
                            } else {
                                DoTransactionRequest request = headerRequest.getDetail();
                                if (request.getInvoiceNo() == null && request.getTransactionLogId() == null) {
                                    onClickSaleTxn(headerRequest);
                                } else {
                                    showEnterDialog(request, headerRequest);
                                }
                            }
                        }
                    });
                    mRootView.addView(view);
                }
            }
        }else {
            if (BuildConfig.UPLOAD_INVOICE){
                View view = LayoutInflater.from(this).inflate(R.layout.view_btn, mRootView, false);
                Button button = view.findViewById(R.id.my_btn);
                if (button!=null){
                    button.setText("UPLOAD INVOICE");
                    button.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            HeaderRequest<InvoiceRequest> headerRequest= new HeaderRequest<>(BillingMethodId.UPLOAD_INVOICE.getValue());
                            InvoiceRequest invoiceRequest= new InvoiceRequest();
                            headerRequest.setDetail(invoiceRequest);
                            onClickSaleTxn(headerRequest);
                        }
                    });
                    mRootView.addView(view);
                }
            }
            for (final TransactionType type : TransactionType.values()) {
                View view = LayoutInflater.from(this).inflate(R.layout.view_btn, mRootView, false);
                Button button = view.findViewById(R.id.my_btn);
                if (button != null) {
                    button.setText(type.toString());
                    button.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            HeaderRequest<DoTransactionRequest> headerRequest = type.getRequest();
                            if (headerRequest == null) {
                                onClickSaleTxn(type.getValue());
                            } else {
                                DoTransactionRequest request = headerRequest.getDetail();
                                if (request.getInvoiceNo() == null && request.getTransactionLogId() == null) {
                                    onClickSaleTxn(headerRequest);
                                } else {
                                    showEnterDialog(request, headerRequest);
                                }
                            }
                        }
                    });
                    mRootView.addView(view);
                }
            }
        }
    }

    /**
     * Invoke Server Service
     */
    public void onClickStart(View view) {
        if (isBound) {
            showMsg("Already Started: " + msg, Toast.LENGTH_LONG);
        } else {
            Intent intent = new Intent();
            intent.setAction("com.pinelabs.masterapp.SERVER");            if (BuildConfig.IS_EPOS){
                intent.setPackage("com.pinelabs.epos");
            }else {
                intent.setPackage("com.pinelabs.masterapp");
            }
            bindService(intent, connection, BIND_AUTO_CREATE);
        }
    }


    /**
     * Call API for Operation
     */
    private void sendMessage(int what, String value) {
        sendMessage(what, value, AppConfig.REQUEST_KEY);
    }

    private void sendMessage(@MsgType.What final int what, final String value, final String key) {
        if (isBound && mServerMessenger != null) {
            Message message = Message.obtain(null, what);
            Bundle data = new Bundle();
            data.putString(key, value);
            message.setData(data);
            try {
                message.replyTo = mClientMessenger;
                mServerMessenger.send(message);

            } catch (RemoteException e) {
                e.printStackTrace();
            }
        } else {
            onClickStart(null);
            showMsg("Starting...", Toast.LENGTH_SHORT);
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    sendMessage(what, value, key);
                }
            }, 2000);
        }
    }


    private String decodePlutusResponse(byte[] byteArray) {
        StringBuilder s = new StringBuilder();
        try {
            byte opType = byteArray[3];
            PlutusOperationType type = PlutusOperationType.getOpType(opType);
            String s1 = new String(byteArray, "UTF-8");
            return type + "|" + s1;
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return s.toString();
    }

    public void onClickSaleTxn(Long transactionType) {
        DoTransactionRequest request = new DoTransactionRequest(transactionType);
        request.setBillingRefNo("TX12345678");
        request.setPaymentAmount(20000L);
        request.setBankCode("2020");
        request.setCardNumber("XXXX 1234 XXXX");
        request.setExpiry("March 2020");
        request.setInvoiceNo(432004L);
        request.setSwipe(true);
        request.setField0("sample");
        request.setField1("sample");
        request.setField2("sample");
        request.setField3("sample");
        request.setBatchNo(102);
        request.setRoc(101);
        request.setTransactionLogId(545L);
        request.setRewardAmount(10000L);
        request.setCustomerMobileNumber("8800000000");
        request.setCustomerEmailId("customer@xyz.com");
        request.setConsentCustomerMobile(false);
        request.setConsentCustomerEmailId(true);
        request.setMerchantMobileNumber("9900000000");
        request.setMerchantEmailId("merchant@xyz.com");
        request.setConsentMerchantMobile(false);
        request.setConsentCustomerEmailId(true);
        request.setWalletProgramId(300L);
        HeaderRequest<DoTransactionRequest> headerRequest = new HeaderRequest<>(BillingMethodId.DO_TRANSACTION.getValue());
        headerRequest.setDetail(request);
        onClickSaleTxn(headerRequest);
    }

    public void onClickSaleTxn(final HeaderRequest request) {
        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View view = LayoutInflater.from(this).inflate(R.layout.layout_edit, null, false);
        builder.setView(view);
        final EditText etRequest = view.findViewById(R.id.et_request);
        Button btnSubmit = view.findViewById(R.id.btn_submit);
        etRequest.setText(request.toString());
        final AlertDialog alertDialog = builder.create();
        alertDialog.show();
        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s = etRequest.getText().toString();
                if (isValid(s)) {
                    sendMessage(ExternalAppActivity.BILLING_APP, s);
                    alertDialog.dismiss();
                } else {
                    showMsg("Invalid Json", Toast.LENGTH_SHORT);
                }
            }
        });


//        btnSubmit.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Intent hybridIntent= new Intent();
//                hybridIntent.setAction("com.pinelabs.HYBRID_REQUEST");
//                hybridIntent.putExtra("BILLING_REQUEST",etRequest.getText().toString()) ;
//                sendBroadcast(hybridIntent);
//            }
//        });
    }

    private boolean isValid(String msg) {
        boolean result;
        try {
            new JSONObject(msg);
            result = true;
        } catch (Exception e) {
            result = false;
            e.printStackTrace();
        }
        return result;
    }

    private void print(String data) {
        PrintRequest printRequest = new PrintRequest(OperationType.PRINT_TXN.getValue());
        List<PrintData> list = new ArrayList<>();
        list.add(new PrintData().setStrDataToPrint(data));
        printRequest.setData(list);
        HeaderRequest<PrintRequest> headerRequest = new HeaderRequest<>(BillingMethodId.PRINT.getValue());
        headerRequest.setDetail(printRequest);
        onClickSaleTxn(headerRequest);
    }

    private void showDialog(final String value, final boolean print) {
        AlertDialog.Builder builder;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            builder = new AlertDialog.Builder(ExternalAppActivity.this, android.R.style.Theme_Holo_Dialog_NoActionBar);
        } else {
            builder = new AlertDialog.Builder(ExternalAppActivity.this);
        }
        if (print) {
            builder.setNegativeButton("Print", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    print(value);
                }
            });
        }
        builder.setTitle("Result")
                .setMessage(value)
                .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {

                    }
                })
                .setIcon(android.R.drawable.ic_dialog_alert)
                .show();
    }

    private void showEnterDialog(final DoTransactionRequest request, final HeaderRequest headerRequest) {
        final AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);
        LayoutInflater inflater = this.getLayoutInflater();

        final View dialogView = inflater.inflate(R.layout.popup_enter, null);
        dialogBuilder.setView(dialogView);

        final AlertDialog b = dialogBuilder.create();

        b.setCancelable(false);
        b.setCanceledOnTouchOutside(false);

        final EditText etInvoice = dialogView.findViewById(R.id.et_invoice);
        final EditText etLogId = dialogView.findViewById(R.id.et_log_id);
        Button btnSubmit = dialogView.findViewById(R.id.btn_submit);

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!TextUtils.isEmpty(etInvoice.getText())) {
                    request.setInvoiceNo(Long.valueOf(etInvoice.getText().toString()));
                } else {
                    request.setInvoiceNo(null);
                }
                if (!TextUtils.isEmpty(etLogId.getText())) {
                    request.setTransactionLogId(Long.valueOf(etLogId.getText().toString()));
                } else {
                    request.setTransactionLogId(null);
                }
                onClickSaleTxn(headerRequest);
                b.dismiss();
            }
        });

        b.show();
    }

    public void onClickConfig(View view) {
        HeaderRequest<DoTransactionRequest> headerRequest = new HeaderRequest<>(BillingMethodId.CONFIGURATION.getValue());
        onClickSaleTxn(headerRequest);
    }

    public void onClickSettlement(View view) {
        HeaderRequest<PrintRequest> headerRequest = new HeaderRequest<>(BillingMethodId.SETTLEMENT.getValue());
        onClickSaleTxn(headerRequest);
    }

    public void onClickPrint(View view) {
        print("PrintData API will be called ThirdPartyApp wants to print data with our service.\n\n\n\n...");
    }

    public void onClickStandAlone(View view) {
        HeaderRequest headerRequest = new HeaderRequest(BillingMethodId.STANDALONE_TRANSACTION.getValue());
        onClickSaleTxn(headerRequest);
    }

    public void onClickDisconnectBluetooth(View view) {
        HeaderRequest<PrintRequest> headerRequest = new HeaderRequest<>(BillingMethodId.DISCONNECT_BLUETOOTH.getValue());
        onClickSaleTxn(headerRequest);
    }

    public void onClickConnectBluetooth(View view) {
        HeaderRequest<BluetoothRequest> headerRequest = new HeaderRequest<>(BillingMethodId.CONNECT_BLUETOOTH.getValue());
        headerRequest.setDetail(BluetoothRequest.setData("1230001132"));
        onClickSaleTxn(headerRequest);
    }

    public void onClickScanCode(View view) {
        HeaderRequest<PrintRequest> headerRequest = new HeaderRequest<>(BillingMethodId.SCAN_CODE.getValue());
        onClickSaleTxn(headerRequest);
    }

    public void onClickScanCodeCamera(View view) {
        HeaderRequest<PrintRequest> headerRequest = new HeaderRequest<>(BillingMethodId.SCAN_CODE_CAMERA.getValue());
        onClickSaleTxn(headerRequest);
    }

    /**
     * Handler of incoming messages from service.
     */
    @SuppressLint("HandlerLeak")
    private class IncomingHandler extends Handler {

        IncomingHandler(HandlerThread thr) {
            super(thr.getLooper());
        }

        @Override
        public void handleMessage(Message msg) {
            //Toast.makeText(ClientDemoActivity.this, "Reply Rx: " + msg.what, Toast.LENGTH_SHORT).show();
            Bundle bundle;
            String value;
            switch (msg.what) {
                case ExternalAppActivity.MASTER_APP:
                    bundle = msg.getData();
                    value = bundle.getString(AppConfig.RESPONSE_KEY);
                    if (TextUtils.isEmpty(value)) {
                        value = decodePlutusResponse(bundle.getByteArray(AppConfig.PLUTUS_RESPONSE_KEY));
                    }

                    BaseResponse response = GsonUtils.fromStringToJson(value, BaseResponse.class);
                    boolean print = false;
                    if (response != null) {
                        value = response.getResponseMessage();
                        if (response.getOperationType() == PeripheralOperationType.SALE.getValue()) {
                            print = true;
                        }
                    }

                    Log.d("kush byte value", value + "");
                    showDialog(value, print);
                    //Toast.makeText(ClientDemoActivity.this, value, Toast.LENGTH_LONG).show();
                    break;
                case ExternalAppActivity.BILLING_APP:
                    bundle = msg.getData();
                    value = bundle.getString(AppConfig.RESPONSE_KEY);
                    DetailResponse detailResponse = GsonUtils.fromStringToJson(value, DetailResponse.class);
                    if (detailResponse != null) {
                        showDialog(value, true);
                    }
                    break;
                default:
                    super.handleMessage(msg);
                    break;
            }
        }
    }
}
