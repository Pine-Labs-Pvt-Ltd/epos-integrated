package com.pinelabs.serverapp.activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;

import com.pinelabs.serverapp.R;

/**
 * Created by Kushaal Singla on 1/16/2019.
 */
public class MainActivity extends BaseActivity{
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void onClickExternalApp(View view) {
        startActivity(new Intent(this,ExternalAppActivity.class));
    }

    public void onClickClientApp(View view) {
        startActivity(new Intent(this,ClientDemoActivity.class));
    }
}
