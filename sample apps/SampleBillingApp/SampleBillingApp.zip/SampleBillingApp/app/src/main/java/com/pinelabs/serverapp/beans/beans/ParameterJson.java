package com.pinelabs.serverapp.beans.beans;

import com.google.gson.annotations.SerializedName;

public class ParameterJson {
    @SerializedName("HardwareID")
    private String hardwareid;
    @SerializedName("FullSerialNumber")
    private String fullserialnumber;

    public String getHardwareId() {
        return hardwareid;
    }

    public void setHardwareId(String hardwareid) {
        this.hardwareid = hardwareid;
    }

    public String getFullSerialNumber() {
        return fullserialnumber;
    }

    public void setFullSerialNumber(String fullserialnumber) {
        this.fullserialnumber = fullserialnumber;
    }
}
