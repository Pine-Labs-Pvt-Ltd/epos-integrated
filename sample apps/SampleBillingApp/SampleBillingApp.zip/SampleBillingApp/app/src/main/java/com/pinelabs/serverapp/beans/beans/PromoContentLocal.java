package com.pinelabs.serverapp.beans.beans;

import com.google.gson.annotations.SerializedName;

/**
 * Created by vikrant.chauhan on 25-05-2018.
 */

public class PromoContentLocal {

    public PromoContentLocal(int resource) {
        this.resource = resource;
    }

    public PromoContentLocal() {

    }

    @SerializedName("ContentDisplayDuration")
    private Long ContentDisplayDuration;
    @SerializedName("ContentTypeId")
    private Integer ContentTypeId;
    @SerializedName("CampaignId")
    private String CampaignId;
    @SerializedName("ContentId")
    private String ContentId;
    @SerializedName("ContentLocalUrl")
    private String ContentLocalUrl;
    @SerializedName("ThumbnailLocalUrl")
    private String ThumbnailLocalUrl;
    @SerializedName("AdditionalInfo")
    private String AdditionalInfo;
    @SerializedName("ContentAutoPlay")
    private Boolean ContentAutoPlay;
    @SerializedName("SectionId")
    private String SectionId;
    private Integer resource;

    public String getSectionId() {
        return SectionId;
    }

    public void setSectionId(String sectionId) {
        SectionId = sectionId;
    }

    public Long getContentDisplayDuration() {
        return ContentDisplayDuration;
    }

    public void setContentDisplayDuration(Long contentDisplayDuration) {
        ContentDisplayDuration = contentDisplayDuration;
    }

    public Integer getContentTypeId() {
        return ContentTypeId;
    }

    public void setContentTypeId(Integer contentTypeId) {
        ContentTypeId = contentTypeId;
    }

    public String getCampaignId() {
        return CampaignId;
    }

    public void setCampaignId(String campaignId) {
        CampaignId = campaignId;
    }

    public String getContentId() {
        return ContentId;
    }

    public void setContentId(String contentId) {
        ContentId = contentId;
    }

    public String getContentLocalUrl() {
        return ContentLocalUrl;
    }

    public void setContentLocalUrl(String contentLocalUrl) {
        ContentLocalUrl = contentLocalUrl;
    }

    public String getThumbnailLocalUrl() {
        return ThumbnailLocalUrl;
    }

    public void setThumbnailLocalUrl(String thumbnailLocalUrl) {
        ThumbnailLocalUrl = thumbnailLocalUrl;
    }

    public String getAdditionalInfo() {
        return AdditionalInfo;
    }

    public void setAdditionalInfo(String additionalInfo) {
        AdditionalInfo = additionalInfo;
    }

    public Boolean getContentAutoPlay() {
        return ContentAutoPlay;
    }

    public void setContentAutoPlay(Boolean contentAutoPlay) {
        ContentAutoPlay = contentAutoPlay;
    }

    @Override
    public String toString() {
        return "PromoContentLocal{" +
                "ContentDisplayDuration='" + ContentDisplayDuration + '\'' +
                ", ContentTypeId='" + ContentTypeId + '\'' +
                ", CampaignId='" + CampaignId + '\'' +
                ", ContentId='" + ContentId + '\'' +
                ", ContentLocalUrl='" + ContentLocalUrl + '\'' +
                ", ThumbnailLocalUrl='" + ThumbnailLocalUrl + '\'' +
                ", AdditionalInfo='" + AdditionalInfo + '\'' +
                ", ContentAutoPlay='" + ContentAutoPlay + '\'' +
                '}';
    }

    public Integer getResource() {
        return resource;
    }

    public void setResource(Integer resource) {
        this.resource = resource;
    }
}
