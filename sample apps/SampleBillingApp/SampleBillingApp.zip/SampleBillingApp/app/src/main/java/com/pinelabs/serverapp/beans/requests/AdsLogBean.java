package com.pinelabs.serverapp.beans.requests;

/*
 * Created by Kushaal Singla on 5/15/2018.
 */

import android.support.annotation.NonNull;
import com.google.gson.annotations.SerializedName;

public class AdsLogBean {

    @NonNull
    @SerializedName("localId")
    private long localId;
    @SerializedName("screenId")
    private String screenId;
    @SerializedName("sectionId")
    private String sectionId;
    @SerializedName("contentId")
    private String contentId;
    @SerializedName("startDateTime")
    private long startDateTime;
    @SerializedName("endDateTime")
    private long endDateTime;
    @SerializedName("campaignId")
    private String campaignId;
    @SerializedName("additionalInfo")
    private String additionalInfo;
    @SerializedName("status")
    private String status;
    @SerializedName("appId")
    private String appId;
    @SerializedName("reqRefId")
    private String reqRefId;

    public String getReqRefId() {
        return reqRefId;
    }

    public void setReqRefId(String reqRefId) {
        this.reqRefId = reqRefId;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public long getLocalId() {
        return localId;
    }

    public void setLocalId(long localId) {
        this.localId = localId;
    }

    public String getScreenId() {
        return screenId;
    }

    public void setScreenId(String screenId) {
        this.screenId = screenId;
    }

    public String getSectionId() {
        return sectionId;
    }

    public void setSectionId(String sectionId) {
        this.sectionId = sectionId;
    }

    public String getContentId() {
        return contentId;
    }

    public void setContentId(String contentId) {
        this.contentId = contentId;
    }

    public long getStartDateTime() {
        return startDateTime;
    }

    public void setStartDateTime(long startDateTime) {
        this.startDateTime = startDateTime;
    }

    public long getEndDateTime() {
        return endDateTime;
    }

    public void setEndDateTime(long endDateTime) {
        this.endDateTime = endDateTime;
    }

    public String getCampaignId() {
        return campaignId;
    }

    public void setCampaignId(String campaignId) {
        this.campaignId = campaignId;
    }

    public String getAdditionalInfo() {
        return additionalInfo;
    }

    public void setAdditionalInfo(String additionalInfo) {
        this.additionalInfo = additionalInfo;
    }

}
