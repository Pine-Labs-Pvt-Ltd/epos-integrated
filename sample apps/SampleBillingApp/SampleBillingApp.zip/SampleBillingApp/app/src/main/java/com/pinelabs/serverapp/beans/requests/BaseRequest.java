package com.pinelabs.serverapp.beans.requests;

import com.google.gson.annotations.SerializedName;
import com.pinelabs.serverapp.utils.GsonUtils;

/*
 * Created by Kushaal Singla on 4/5/2018.
 */

public class BaseRequest {

    public BaseRequest(int operationType){
        this.operationType = operationType;
    }

    public BaseRequest(int operationType, String userId){
        this.operationType = operationType;
        this.userId = userId;
    }

    @SerializedName("OperationType")
    private int operationType;

    @SerializedName("UserId")
    private String userId;


    public int getOperationType() {
        return operationType;
    }

    public void setOperationType(int operationType) {
        this.operationType = operationType;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    @Override
    public String toString() {
        return GsonUtils.fromJsonToString(this);
    }
}
