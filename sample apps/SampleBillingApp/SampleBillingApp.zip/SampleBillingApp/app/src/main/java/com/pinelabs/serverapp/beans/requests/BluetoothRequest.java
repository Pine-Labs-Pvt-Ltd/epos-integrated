package com.pinelabs.serverapp.beans.requests;

import com.google.gson.annotations.SerializedName;

public class BluetoothRequest {
    @SerializedName("BaseSerialNumber")
    private String BaseSerialNumber;

    public BluetoothRequest(String s) {
        this.BaseSerialNumber = s;
    }

    public static BluetoothRequest setData(String s) {
        return new BluetoothRequest(s);
    }
}
