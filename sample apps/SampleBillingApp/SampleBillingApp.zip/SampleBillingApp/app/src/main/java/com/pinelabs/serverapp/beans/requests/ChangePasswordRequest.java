package com.pinelabs.serverapp.beans.requests;

import com.google.gson.annotations.SerializedName;

/**
 * Created by vikrant.chauhan on 10-05-2018.
 */

public class ChangePasswordRequest extends BaseRequest {

    public ChangePasswordRequest(int operationType, String userId, String currentPin, String newPin) {
        super(operationType, userId);
        this.currentPin = currentPin;
        this.newPin = newPin;
    }

    @SerializedName("NewPin")
    private String newPin;

    @SerializedName("CurrentPin")
    private String currentPin;

    public String getNewPin() {
        return newPin;
    }

    public void setNewPin(String newPin) {
        this.newPin = newPin;
    }

    public String getCurrentPin() {
        return currentPin;
    }

    public void setCurrentPin(String currentPin) {
        this.currentPin = currentPin;
    }
}
