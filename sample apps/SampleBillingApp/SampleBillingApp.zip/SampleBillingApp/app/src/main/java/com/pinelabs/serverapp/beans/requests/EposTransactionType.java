package com.pinelabs.serverapp.beans.requests;

import com.pinelabs.serverapp.enums.BillingMethodId;

public enum EposTransactionType {

    Epos_CC_DC_SALE(
            new DoTransactionRequest(5561L)
                    .setBillingRefNo("TX12345678")
                    .setBankCode("01")
                    .setPaymentAmount(9900L)
    ),
    Epos_CC_DC_Void(new DoTransactionRequest(5562L)
            .setBillingRefNo("TX12345678")
            .setBankCode("01")
            .setPaymentAmount(9900L)
            .setBatchNo(9001)
            .setRoc(0101)),
    Epos_Get_Status(new DoTransactionRequest(5563L)
            .setBillingRefNo("TX12345678")
            .setBankCode("01")
            .setPaymentAmount(7700L)
            .setBatchNo(9011)
            .setRoc(103)),
    Epos_Resend_Sms(new DoTransactionRequest(5564L)
            .setBillingRefNo("TX12345678")
            .setBankCode("01")
            .setPaymentAmount(9900L)
            .setBatchNo(9010)
            .setRoc(124)),
    Epos_Bank_Emi(new DoTransactionRequest(5566L)
            .setBillingRefNo("TX12345678")
            .setBankCode("01")
            .setPaymentAmount(100L)),
    Epos_Bank_Emi_Void(new DoTransactionRequest(5563L)
            .setBillingRefNo("TX12345678")
            .setBankCode("01")
            .setPaymentAmount(8800L)
            .setBatchNo(9003)
            .setRoc(103)),
    Epos_BankEmi_Get_Status(new DoTransactionRequest(5563L)
            .setBillingRefNo("TX12345678")
            .setBankCode("01")
            .setPaymentAmount(7700L)
            .setBatchNo(9009)
            .setRoc(103)),
    Epos_BankEmi_ResendSms(new DoTransactionRequest(5564L)
            .setBillingRefNo("TX12345678")
            .setBankCode("01")
            .setPaymentAmount(8800L)
            .setBatchNo(9009)
            .setRoc(109)),
    Epos_Brand_Emi(new DoTransactionRequest(5567L)
            .setBillingRefNo("TX2323")
            .setBankCode("01")
            .setPaymentAmount(2000L)),
    Epos_BrandEmi_Void(new DoTransactionRequest(5562L)
            .setBillingRefNo("TX12345678")
            .setBankCode("01")
            .setPaymentAmount(3300L)
            .setBatchNo(9010)
            .setRoc(108)),
    Epos_BrandEmi_GetStatus(new DoTransactionRequest(5563L)
            .setBillingRefNo("TX12345678")
            .setBankCode("01")
            .setPaymentAmount(3300L)
            .setBatchNo(9010)
            .setRoc(108)),
    Epos_BrandEmi_ResendSms(new DoTransactionRequest(5564L)
            .setBillingRefNo("TX12345678")
            .setBankCode("01")
            .setPaymentAmount(9900L)
            .setBatchNo(9010)
            .setRoc(111)),
    FreeCharge(new DoTransactionRequest(5102L)
            .setBillingRefNo("TX333333")
            .setBankCode("103")
            .setPaymentAmount(100L)),
    PhonePe(new DoTransactionRequest(5102L)
            .setBillingRefNo("TX2222")
            .setBankCode("105")
            .setPaymentAmount(100L)),
    AirtelMoney(new DoTransactionRequest(5127L)
            .setBillingRefNo("TX333333")
            .setPaymentAmount(100L)),
    HdfcUpi(new DoTransactionRequest(5120L)
            .setBillingRefNo("1245")
            .setBankCode("2")
            .setPaymentAmount(100L)),
    BharatQR(new DoTransactionRequest(5123L)
            .setBillingRefNo("TX12345678")
            .setBankCode("01")
            .setPaymentAmount(9900L));
    private Long value;
    private HeaderRequest<DoTransactionRequest> request;

    EposTransactionType(Long i) {
        this.value = i;
    }

    EposTransactionType(DoTransactionRequest doTransactionRequest) {
        request = new HeaderRequest<>(BillingMethodId.DO_TRANSACTION.getValue());
        request.setDetail(doTransactionRequest);
    }

    public HeaderRequest<DoTransactionRequest> getRequest() {
        return request;
    }

    public Long getValue() {
        return value;
    }
}
