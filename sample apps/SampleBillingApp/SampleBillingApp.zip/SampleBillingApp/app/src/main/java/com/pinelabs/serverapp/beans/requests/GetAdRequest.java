package com.pinelabs.serverapp.beans.requests;

import com.google.gson.annotations.SerializedName;

/*
 * Created by Kushaal Singla on 5/10/2018.
 */

public class GetAdRequest extends BaseRequest {
    public GetAdRequest(int operationType) {
        super(operationType);
    }
    @SerializedName("ReqRefId")
    private String ReqRefId;
    @SerializedName("AppId")
    private String AppId;
    @SerializedName("ScreenId")
    private String ScreenId;

    public String getReqRefId() {
        return ReqRefId;
    }

    public void setReqRefId(String reqRefId) {
        ReqRefId = reqRefId;
    }

    public String getAppId() {
        return AppId;
    }

    public void setAppId(String appId) {
        AppId = appId;
    }

    public String getScreenId() {
        return ScreenId;
    }

    public void setScreenId(String screenId) {
        ScreenId = screenId;
    }
}
