package com.pinelabs.serverapp.beans.requests;

import com.google.gson.annotations.SerializedName;
import com.pinelabs.serverapp.utils.GsonUtils;

public class HeaderRequest<T> {

    public HeaderRequest(String methodId) {
        this.Header = new Header("1001", methodId, "userId", "1.0");
    }

    @SerializedName("Header")
    private Header Header;

    @SerializedName("Detail")
    private T Detail;

    public Header getHeader() {
        return Header;
    }

    public void setHeader(Header header) {
        Header = header;
    }

    public T getDetail() {
        return Detail;
    }

    public void setDetail(T detail) {
        Detail = detail;
    }

    @Override
    public String toString() {
        return GsonUtils.fromJsonToString(this);
    }
}
