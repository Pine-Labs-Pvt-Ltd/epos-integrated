package com.pinelabs.serverapp.beans.requests;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

public class InvoiceRequest {

    @SerializedName("OrderId")
    @Expose
    private String orderID;
    @SerializedName("InvoiceNumber")
    @Expose
    private Integer invoiceNumber;
    @SerializedName("OrderCreationTimeLocal")
    @Expose
    private String orderCreationTimeLocal;
    @SerializedName("NetBill")
    @Expose
    private Integer netBill;
    @SerializedName("Taxes")
    @Expose
    private Integer taxes;
    @SerializedName("DiscountTotalValue")
    @Expose
    private Integer discountTotalValue;
    @SerializedName("GrossBill")
    @Expose
    private Integer grossBill;
    @SerializedName("BillingUserName")
    @Expose
    private String billingUsername;
    @SerializedName("Payments")
    @Expose
    private List<Payment> payments = null;
    @SerializedName("Products")
    @Expose
    private List<Product> products = null;
    @SerializedName("Customer")
    @Expose
    private Customer customer;
    @SerializedName("PaymentStatus")
    @Expose
    private String paymentStatus;
    @SerializedName("Status")
    @Expose
    private String status;

    public InvoiceRequest() {
        this.orderID = "OR-123-1";
        this.invoiceNumber = 1;
        this.orderCreationTimeLocal = "2019-04-01";
        this.netBill = 5000;
        this.taxes = 100;
        this.discountTotalValue = 50;
        this.grossBill = 5500;
        this.billingUsername = "nikhil";
        this.payments = getPayments();
        this.products = getProducts();
        this.customer = getCustomer();
        this.paymentStatus = "PAID";
        this.status = "DELIVERED";

    }

    public String getOrderID() {
        return orderID;
    }

    public void setOrderID(String orderID) {
        this.orderID = orderID;
    }

    public Integer getInvoiceNumber() {
        return invoiceNumber;
    }

    public void setInvoiceNumber(Integer invoiceNumber) {
        this.invoiceNumber = invoiceNumber;
    }

    public String getOrderCreationTimeLocal() {
        return orderCreationTimeLocal;
    }

    public void setOrderCreationTimeLocal(String orderCreationTimeLocal) {
        this.orderCreationTimeLocal = orderCreationTimeLocal;
    }

    public Integer getNetBill() {
        return netBill;
    }

    public void setNetBill(Integer netBill) {
        this.netBill = netBill;
    }

    public Integer getTaxes() {
        return taxes;
    }

    public void setTaxes(Integer taxes) {
        this.taxes = taxes;
    }

    public Integer getDiscountTotalValue() {
        return discountTotalValue;
    }

    public void setDiscountTotalValue(Integer discountTotalValue) {
        this.discountTotalValue = discountTotalValue;
    }

    public Integer getGrossBill() {
        return grossBill;
    }

    public void setGrossBill(Integer grossBill) {
        this.grossBill = grossBill;
    }

    public String getBillingUsername() {
        return billingUsername;
    }

    public void setBillingUsername(String billingUsername) {
        this.billingUsername = billingUsername;
    }

    public List<Payment> getPayments() {
        List<Payment> paymentList=new ArrayList<>();
        Payment payment1=new Payment("123","PAYMENT_CASH",2000,"");
        Payment payment2=new Payment("456","PAYMENT_CARD",3500,"CARD_VISA");
        paymentList.add(payment1);
        paymentList.add(payment2);
        return paymentList;
    }

    public void setPayments(List<Payment> payments) {
        this.payments = payments;
    }

    public List<Product> getProducts() {
        List<Product> productList=new ArrayList<>();
        Product p=new Product();
        productList.add(p);
        return productList;
    }

    public void setProducts(List<Product> products) {
        this.products = products;
    }


    public String getPaymentStatus() {
        return paymentStatus;
    }

    public void setPaymentStatus(String paymentStatus) {
        this.paymentStatus = paymentStatus;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }


    public Customer getCustomer() {
        Customer newCustomer=new Customer();
        return newCustomer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }
}
