package com.pinelabs.serverapp.beans.requests;

import com.google.gson.annotations.SerializedName;

/*
 * Created by Kushaal Singla on 5/10/2018.
 */

public class LaunchAppRequest extends BaseRequest {
    @SerializedName("CardHash")
    private String cardHash;
    @SerializedName("TransactionType")
    private String transactionType;
    @SerializedName("ResponseCSV")
    private String responseCSV;

    public LaunchAppRequest(int operationType) {
        super(operationType);
    }


    public String getCardHash() {
        return cardHash;
    }

    public void setCardHash(String cardHash) {
        this.cardHash = cardHash;
    }

    public String getTransactionType() {
        return transactionType;
    }

    public void setTransactionType(String transactionType) {
        this.transactionType = transactionType;
    }

    public String getResponseCSV() {
        return responseCSV;
    }

    public void setResponseCSV(String responseCSV) {
        this.responseCSV = responseCSV;
    }
}
