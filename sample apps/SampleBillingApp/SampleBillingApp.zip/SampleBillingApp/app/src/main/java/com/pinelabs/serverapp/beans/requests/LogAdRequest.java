package com.pinelabs.serverapp.beans.requests;

import com.google.gson.annotations.SerializedName;

import java.util.List;

/*
 * Created by Kushaal Singla on 5/10/2018.
 */

public class LogAdRequest extends BaseRequest {

    public LogAdRequest(int operationType) {
        super(operationType);
    }

    @SerializedName("AdLogs")
    private List<AdsLogBean> AdLogs;

    public List<AdsLogBean> getAdLogs() {
        return AdLogs;
    }

    public void setAdLogs(List<AdsLogBean> adLogs) {
        AdLogs = adLogs;
    }
}
