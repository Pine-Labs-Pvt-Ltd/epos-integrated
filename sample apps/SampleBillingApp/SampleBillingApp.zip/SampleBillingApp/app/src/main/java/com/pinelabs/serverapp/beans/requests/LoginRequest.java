package com.pinelabs.serverapp.beans.requests;

import com.google.gson.annotations.SerializedName;

/**
 * Created by vikrant.chauhan on 10-05-2018.
 */

public class LoginRequest extends BaseRequest {

    public LoginRequest(int operationType, String userId, String userPin) {
        super(operationType, userId);
        this.userPin = userPin;
    }

    @SerializedName("UserPin")
    private String userPin;


    public String getUserPin() {
        return userPin;
    }

    public void setUserPin(String userPin) {
        this.userPin = userPin;
    }
}
