package com.pinelabs.serverapp.beans.requests;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Payment {

    @SerializedName("PaymentId")
    @Expose
    private String paymentId;
    @SerializedName("PaymentType")
    @Expose
    private String paymentType;
    @SerializedName("Amount")
    @Expose
    private Integer amount;
    @SerializedName("CardType")
    @Expose
    private String cardType;

    public Payment(String paymentId,String paymentType, Integer amount, String cardType) {
        this.paymentId=paymentId;
        this.paymentType = paymentType;
        this.amount = amount;
        this.cardType = cardType;
    }

    public String getPaymentType() {
        return paymentType;
    }

    public void setPaymentType(String paymentType) {
        this.paymentType = paymentType;
    }

    public Integer getAmount() {
        return amount;
    }

    public void setAmount(Integer amount) {
        this.amount = amount;
    }

    public String getCardType() {
        return cardType;
    }

    public void setCardType(String cardType) {
        this.cardType = cardType;
    }

    public String getPaymentId() {
        return paymentId;
    }

    public void setPaymentId(String paymentId) {
        this.paymentId = paymentId;
    }
}
