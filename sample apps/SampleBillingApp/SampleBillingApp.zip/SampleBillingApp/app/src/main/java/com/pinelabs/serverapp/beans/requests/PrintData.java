package com.pinelabs.serverapp.beans.requests;

import com.google.gson.annotations.SerializedName;

public class PrintData {

    @SerializedName("strDataToPrint")
    private String strDataToPrint;
    @SerializedName("strImagePath")
    private String strImagePath;
    @SerializedName("strImageData")
    private String strImageData;
    @SerializedName("IsCenterAligned")
    private Boolean IsCenterAligned;
    @SerializedName("iPrinterWidth")
    private Integer iPrinterWidth;
    @SerializedName("iPrintDataType")
    private Integer iPrintDataType;

    public String getStrDataToPrint() {
        return strDataToPrint;
    }

    public PrintData setStrDataToPrint(String strDataToPrint) {
        this.strDataToPrint = strDataToPrint;
        return this;
    }

    public String getStrImagePath() {
        return strImagePath;
    }

    public void setStrImagePath(String strImagePath) {
        this.strImagePath = strImagePath;
    }

    public String getStrImageData() {
        return strImageData;
    }

    public void setStrImageData(String strImageData) {
        this.strImageData = strImageData;
    }

    public Boolean getCenterAligned() {
        return IsCenterAligned;
    }

    public void setCenterAligned(Boolean centerAligned) {
        IsCenterAligned = centerAligned;
    }

    public Integer getiPrinterWidth() {
        return iPrinterWidth;
    }

    public void setiPrinterWidth(Integer iPrinterWidth) {
        this.iPrinterWidth = iPrinterWidth;
    }

    public Integer getiPrintDataType() {
        return iPrintDataType;
    }

    public void setiPrintDataType(Integer iPrintDataType) {
        this.iPrintDataType = iPrintDataType;
    }
}
