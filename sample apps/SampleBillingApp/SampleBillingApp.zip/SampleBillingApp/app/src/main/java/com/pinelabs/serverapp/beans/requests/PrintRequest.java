package com.pinelabs.serverapp.beans.requests;

import com.google.gson.annotations.SerializedName;

import java.util.List;

/*
 * Created by Kushaal Singla on 5/10/2018.
 */

public class PrintRequest extends BaseRequest {
    public PrintRequest(int operationType) {
        super(operationType);
    }
    @SerializedName("Data")
    private List<PrintData> Data;

    public List<PrintData> getData() {
        return Data;
    }

    public void setData(List<PrintData> data) {
        Data = data;
    }
}
