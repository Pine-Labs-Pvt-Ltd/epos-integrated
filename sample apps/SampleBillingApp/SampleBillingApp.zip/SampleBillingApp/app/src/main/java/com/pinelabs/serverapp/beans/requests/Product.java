package com.pinelabs.serverapp.beans.requests;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Product {

    @SerializedName("ProductId")
    @Expose
    private String productID;
    @SerializedName("ProductName")
    @Expose
    private String productName;
    @SerializedName("Quantity")
    @Expose
    private Integer quantity;
    @SerializedName("ProductBasePrice")
    @Expose
    private Integer productBasePrice;
    @SerializedName("ProductValue")
    @Expose
    private Integer productValue;
    @SerializedName("DiscountTotalValue")
    @Expose
    private Integer discountTotalValue;
    @SerializedName("TaxTotalValue")
    @Expose
    private Integer taxTotalValue;
    @SerializedName("AdditionalChargeValue")
    @Expose
    private Integer additionalChargeValue;
    @SerializedName("SkuId")
    @Expose
    private Integer sku;
    @SerializedName("BarCode")
    @Expose
    private Integer barcode;
    @SerializedName("VoidQuantity")
    @Expose
    private Integer voidQuantity;
    @SerializedName("VoidAmount")
    @Expose
    private Integer voidAmount;

    public Product() {
        this.productID = "PROD2001";
        this.productName = "Food Packet";
        this.quantity = 5;
        this.productBasePrice = 1000;
        this.productValue = 5500;
        this.discountTotalValue = 50;
        this.taxTotalValue = 100;
        this.additionalChargeValue = 0;
        this.sku = 0;
        this.barcode = 0;
        this.voidQuantity = 0;
        this.voidAmount = 0;
    }

    public String getProductID() {
        return productID;
    }

    public void setProductID(String productID) {
        this.productID = productID;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public Integer getProductBasePrice() {
        return productBasePrice;
    }

    public void setProductBasePrice(Integer productBasePrice) {
        this.productBasePrice = productBasePrice;
    }

    public Integer getProductValue() {
        return productValue;
    }

    public void setProductValue(Integer productValue) {
        this.productValue = productValue;
    }

    public Integer getDiscountTotalValue() {
        return discountTotalValue;
    }

    public void setDiscountTotalValue(Integer discountTotalValue) {
        this.discountTotalValue = discountTotalValue;
    }

    public Integer getTaxTotalValue() {
        return taxTotalValue;
    }

    public void setTaxTotalValue(Integer taxTotalValue) {
        this.taxTotalValue = taxTotalValue;
    }

    public Integer getAdditionalChargeValue() {
        return additionalChargeValue;
    }

    public void setAdditionalChargeValue(Integer additionalChargeValue) {
        this.additionalChargeValue = additionalChargeValue;
    }

    public Integer getSku() {
        return sku;
    }

    public void setSku(Integer sku) {
        this.sku = sku;
    }

    public Integer getBarcode() {
        return barcode;
    }

    public void setBarcode(Integer barcode) {
        this.barcode = barcode;
    }

    public Integer getVoidQuantity() {
        return voidQuantity;
    }

    public void setVoidQuantity(Integer voidQuantity) {
        this.voidQuantity = voidQuantity;
    }

    public Integer getVoidAmount() {
        return voidAmount;
    }

    public void setVoidAmount(Integer voidAmount) {
        this.voidAmount = voidAmount;
    }

}
