package com.pinelabs.serverapp.beans.responses;

/*
 * Created by Kushaal Singla on 5/10/2018.
 */

import com.google.gson.annotations.SerializedName;
import com.pinelabs.serverapp.beans.beans.ParameterJson;

public class ActivationResponse extends BaseResponse {

    @SerializedName("ParameterJson")
    private ParameterJson parameterJson;
    @SerializedName("AppVersion")
    private String appVersion;
    @SerializedName("ClientId")
    private int clientId;

    public ParameterJson getParameters() {
        return parameterJson;
    }

    public void setParameters(ParameterJson parameterjson) {
        this.parameterJson = parameterjson;
    }

    public String getAppVersion() {
        return appVersion;
    }

    public void setAppVersion(String appversion) {
        this.appVersion = appversion;
    }

    public int getClientId() {
        return clientId;
    }

    public void setClientId(int clientid) {
        this.clientId = clientid;
    }
}
