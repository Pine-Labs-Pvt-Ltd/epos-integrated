package com.pinelabs.serverapp.beans.responses;


import com.google.gson.annotations.SerializedName;
public class DetailResponse<T>{

    @SerializedName("Detail")
    private T Detail;

    @SerializedName("Header")
    private Header Header;

    @SerializedName("Response")
    private Response Response;



}
