package com.pinelabs.serverapp.beans.responses;

/*
 * Created by Kushaal Singla on 5/10/2018.
 */

import com.google.gson.annotations.SerializedName;

public class GetAppStatusResponse extends BaseResponse {

    @SerializedName("AppStatus")
    private int AppStatus;
    @SerializedName("AppVersion")
    private String AppVersion;

    public int getAppStatus() {
        return AppStatus;
    }

    public void setAppStatus(int appStatus) {
        AppStatus = appStatus;
    }

    public String getAppVersion() {
        return AppVersion;
    }

    public void setAppVersion(String appVersion) {
        AppVersion = appVersion;
    }
}
