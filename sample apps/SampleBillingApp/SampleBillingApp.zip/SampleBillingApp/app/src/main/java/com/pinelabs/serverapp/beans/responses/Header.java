package com.pinelabs.serverapp.beans.responses;

import com.google.gson.annotations.SerializedName;

public class Header {

    @SerializedName("ApplicationId")
    private String ApplicationId;

    @SerializedName("MethodId")
    private String MethodId;

    @SerializedName("UserId")
    private String UserId;

    @SerializedName("VersionNo")
    private String VersionNo;

    public String getApplicationId() {
        return ApplicationId;
    }

    public String getMethodId() {
        return MethodId;
    }

    public String getUserId() {
        return UserId;
    }

    public String getVersionNo() {
        return VersionNo;
    }
}
