package com.pinelabs.serverapp.beans.responses;

/*
 * Created by Kushaal Singla on 5/10/2018.
 */

import com.google.gson.annotations.SerializedName;

public class LoginResponse extends BaseResponse {
    @SerializedName("UserId")
    private String UserId;

    public String getUserId() {
        return UserId;
    }

    public void setUserId(String userId) {
        UserId = userId;
    }
}
