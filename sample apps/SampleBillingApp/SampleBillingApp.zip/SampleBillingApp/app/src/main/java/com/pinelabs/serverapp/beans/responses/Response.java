package com.pinelabs.serverapp.beans.responses;

import com.google.gson.annotations.SerializedName;

public class Response {

    @SerializedName("AppVersion")
    private String AppVersion;

    @SerializedName("ParameterJson")
    private String ParameterJson;

    @SerializedName("ResponseCode")
    private String ResponseCode;

    @SerializedName("ResponseMsg")
    private String ResponseMsg;

    public String getAppVersion() {
        return AppVersion;
    }

    public void setAppVersion(String appVersion) {
        AppVersion = appVersion;
    }

    public String getParameterJson() {
        return ParameterJson;
    }

    public void setParameterJson(String parameterJson) {
        ParameterJson = parameterJson;
    }

    public String getResponseCode() {
        return ResponseCode;
    }

    public void setResponseCode(String responseCode) {
        ResponseCode = responseCode;
    }

    public String getResponseMsg() {
        return ResponseMsg;
    }

    public void setResponseMsg(String responseMsg) {
        ResponseMsg = responseMsg;
    }
}
