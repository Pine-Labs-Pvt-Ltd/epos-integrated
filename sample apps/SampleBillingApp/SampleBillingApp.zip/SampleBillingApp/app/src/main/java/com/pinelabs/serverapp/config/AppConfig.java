package com.pinelabs.serverapp.config;

/*
 * Created by Kushaal Singla on 5/9/2018.
 */

public class AppConfig {
    public static final String THIRD_PARTY_REQUEST_KEY = "PERIPHERAL_REQUEST";
    public static final String THIRD_PARTY_RESPONSE_KEY = "PERIPHERAL_RESPONSE";

    public static final String REQUEST_KEY = "MASTERAPPREQUEST";
    public static final String RESPONSE_KEY = "MASTERAPPRESPONSE";
    public static final String BILLING_REQUEST_KEY = "BILLINGAPPREQUEST";

    public static final String PLUTUS_RESPONSE_KEY = "MASTERAPPRESPONSE";
    public static final String PLUTUS_REQUEST_KEY = "MASTERAPPREQUEST";
}
