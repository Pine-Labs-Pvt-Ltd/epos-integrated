package com.pinelabs.serverapp.config;

import android.app.Application;
import android.content.Context;

/**
 * Created by Kushaal Singla on 1/17/2019.
 */
public class MyApplication extends Application {
    private static Context context;

    public static Context getContext() {
        return context;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        context = this;
    }
}
