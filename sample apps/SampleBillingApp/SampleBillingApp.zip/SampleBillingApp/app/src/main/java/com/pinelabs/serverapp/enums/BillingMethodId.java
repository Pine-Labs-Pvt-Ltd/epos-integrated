package com.pinelabs.serverapp.enums;

/*
 * Created by Kushaal Singla on 5/9/2018.
 */

public enum BillingMethodId {

    CONFIGURATION("1000"),
    DO_TRANSACTION("1001"),
    PRINT("1002"),
    SETTLEMENT("1003"),
    STANDALONE_TRANSACTION("1004"),
    CONNECT_BLUETOOTH("1005"),
    DISCONNECT_BLUETOOTH("1006"),
    SCAN_CODE("1007"),
    UPLOAD_INVOICE("1008"),
    SCAN_CODE_CAMERA("1009");

    private String value;

    BillingMethodId(String s) {
        value = s;
    }

    public String getValue() {
        return value;
    }
}
