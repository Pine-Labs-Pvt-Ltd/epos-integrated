package com.pinelabs.serverapp.enums;

import android.support.annotation.IntDef;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

public enum MsgType {
    MASTER_APP(2);

    private final int value;

    public int getValue() {
        return value;
    }

    MsgType(int i) {
        this.value = i;
    }

    @Retention(RetentionPolicy.RUNTIME)
    @IntDef({0,1,2})
    public @interface What {
    }
}
