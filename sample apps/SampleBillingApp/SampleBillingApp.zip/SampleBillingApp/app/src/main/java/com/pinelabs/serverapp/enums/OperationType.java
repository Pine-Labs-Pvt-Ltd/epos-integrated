package com.pinelabs.serverapp.enums;

/*
 * Created by Kushaal Singla on 5/9/2018.
 */

public enum OperationType {
    ACTIVATION(1001),
    SETTLEMENT(1002),
    GET_APP_STATUS(1003),
    LOGIN(1004),
    CHANGE_PASSWORD(1005),
    ADD_USER(1006),
    DELETE_USER(1007),
    LAUNCH_APP(1008),
    LAUNCH_APP_CONFIG(1009),
    SALE_TXN(1011),
    PRINT_TXN(1012);

    private final int value;

    OperationType(int i) {
        this.value = i;
    }

    public static boolean isExists(int operationType) {
        for (OperationType type : values()) {
            if (type.getValue() == operationType) {
                return true;
            }
        }
        return false;
    }

    public int getValue() {
        return value;
    }
}
