package com.pinelabs.serverapp.enums;

/*
 * Created by Kushaal Singla on 5/9/2018.
 */

public enum PeripheralOperationType {
    PRINT(3001),
    SALE(3002);

    private final int value;

    PeripheralOperationType(int i) {
        this.value = i;
    }

    public int getValue() {
        return value;
    }
}
