package com.pinelabs.serverapp.enums;

/*
 * Created by Kushaal Singla on 5/9/2018.
 */

public enum PlutusOperationType {
    ACTIVATION((byte) (0x87)),
    INITIALIZATION((byte) (0x88)),
    SETTLEMENT((byte) (0x89)),
    GET_APP_STATUS((byte) (0x90)),
    LOGIN((byte) (0x91)),
    CHANGE_PASSWORD((byte) (0x92)),
    ADD_USER((byte) (0x93)),
    DELETE_USER((byte) (0x94)),
    PRINT_BILLING_CHARGE_SLIP((byte) (0x95)),
    RUN_PVM((byte) (0x96)),
    DO_TRANSACTION((byte) (0x97)),
    SET_CONNECTION((byte) (0x98));

    private final byte value;

    PlutusOperationType(byte i) {
        this.value = i;
    }

    public static boolean isExists(byte operationType) {
        for (PlutusOperationType type : values()) {
            if (type.getValue() == operationType) {
                return true;
            }
        }
        return false;
    }

    public static PlutusOperationType getOpType(byte opType) {
        for (PlutusOperationType type : values()) {
            if (type.getValue() == opType) {
                return type;
            }
        }
        return null;
    }

    public byte getValue() {
        return value;
    }
}
