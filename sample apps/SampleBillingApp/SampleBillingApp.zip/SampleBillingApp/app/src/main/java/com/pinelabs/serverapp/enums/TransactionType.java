package com.pinelabs.serverapp.enums;

import com.pinelabs.serverapp.beans.requests.DoTransactionRequest;
import com.pinelabs.serverapp.beans.requests.HeaderRequest;

import java.util.HashMap;

public enum TransactionType {

    Sale_Transaction(new DoTransactionRequest(
            4001L).setBillingRefNo("TX12345678").setPaymentAmount(9900L)),
    Refund_Transaction(new DoTransactionRequest(
            4002L).setBillingRefNo("TX12345678").setPaymentAmount(9900L).setBankCode("01").setCardNumber("123456789876")),
    CD_Transaction(new DoTransactionRequest(
            5561L).setBillingRefNo("TX12345678").setPaymentAmount(9900L).setBankCode("01")),
    TipAdjustTransaction(new DoTransactionRequest(
            4015L).setBillingRefNo("TX12345678").setPaymentAmount(9900L).setBankCode("02").setInvoiceNo(37L)),
    AdjustTransaction(new DoTransactionRequest(
            4005L).setBillingRefNo("TX12345678").setPaymentAmount(9900L).setBankCode("02").setInvoiceNo(37L)),
    VoidTransaction(new DoTransactionRequest(
            4006L).setBillingRefNo("TX12345678").setPaymentAmount(9900L).setBankCode("02").setInvoiceNo(37L)),
    PreAuthTransaction(new DoTransactionRequest(
            4007L).setBillingRefNo("TX12345678").setPaymentAmount(9900L).setBankCode("02")),
    SaleCompleteTransaction(new DoTransactionRequest(
            4008L).setBillingRefNo("TX12345678").setPaymentAmount(9900L).setBankCode("02").setInvoiceNo(37L)),
    LoyaltyMineRedemption(new DoTransactionRequest(
            4201L).setBillingRefNo("TX12345678").setPaymentAmount(9900L)),
    mWalletRedemption(new DoTransactionRequest(
            4214L).setBillingRefNo("TX12345678").setPaymentAmount(9900L)),
    Pine360LoyaltyAward(new DoTransactionRequest(
            4208L).setBillingRefNo("TX12345678").setPaymentAmount(9900L)),
    Pine360LoyaltyRedeem(new DoTransactionRequest(
            4209L).setBillingRefNo("TX12345678").setPaymentAmount(9900L)),
    Pine360LoyaltyBalEnquiry(new DoTransactionRequest(
            4210L).setBillingRefNo("TX12345678")),
    Pine360PPC_GVLoad(new DoTransactionRequest(
            4202L).setBillingRefNo("TX12345678").setPaymentAmount(9900L)),
    Pine360PPC_GVRedeem(new DoTransactionRequest(
            4203L).setBillingRefNo("TX12345678").setPaymentAmount(9900L)),
    Pine360PPC_GVBalEnquiry(new DoTransactionRequest(
            4204L).setBillingRefNo("TX12345678")),
    Pine360VoucherRedeem(new DoTransactionRequest(
            4215L).setBillingRefNo("TX12345678").setPaymentAmount(9900L)),
    Pine360GCLoad(new DoTransactionRequest(
            4211L).setBillingRefNo("TX12345678").setPaymentAmount(9900L)),
    Pine360GCRedeem(new DoTransactionRequest(
            4212L).setBillingRefNo("TX12345678").setPaymentAmount(9900L)),
    Pine360GCBalEnquiry(new DoTransactionRequest(
            4213L).setBillingRefNo("TX12345678")),
    FetchLoyaltyNumber(new DoTransactionRequest(
            4301L).setBillingRefNo("TX12345678")),
    RewardRedemption(new DoTransactionRequest(
            4101L).setBillingRefNo("TX12345678").setPaymentAmount(9900L)),
    RewardVoid(new DoTransactionRequest(
            4102L).setBillingRefNo("TX12345678").setPaymentAmount(100L).setField1("Operator").setTransactionLogId(9001L).setRewardAmount(116L)),
    PaybackEarn(4404L),
    PaybackRedemption(4402L),
    PaybackVoid(4403L),
    SaleWithRebate(new DoTransactionRequest(
            4501L).setBillingRefNo("TX12345678").setPaymentAmount(9999000L).setRewardAmount(888800L)),
    SaleWithCash(new DoTransactionRequest(
            4502L).setBillingRefNo("TX12345678").setPaymentAmount(9900L).setRewardAmount(8800L)),
    CashOnly(4503L),
    RePrint(4504L),
    Settlement(new DoTransactionRequest( 6001L)),
    DebitCredit_Transaction(
            new DoTransactionRequest(5561L)
                    .setBillingRefNo("TX12345678")
                    .setBankCode("01")
                    .setPaymentAmount(9900L)
    ),
    WalletPay(new DoTransactionRequest( 5127L).setBillingRefNo("TX12345678").setPaymentAmount(100L)),
    WalletLoad(5103L),
    WalletVoid(new DoTransactionRequest( 5104L).setBillingRefNo("TX12345678").setPaymentAmount(100L).setBatchNo(9023).setRoc(119)),
    WalletStatus(new DoTransactionRequest( 5112L).setBillingRefNo("TX12345678").setPaymentAmount(100L).setBatchNo(9023).setRoc(119)),
    SodexoSale(new DoTransactionRequest( 5106L).setBillingRefNo("T000150100000332").setPaymentAmount(100L)),
    SodexoVoid(new DoTransactionRequest( 5107L).setBillingRefNo("T000150100000334").setPaymentAmount(3060L).setBatchNo(9001).setRoc(101)),
    UPI_SALE(new DoTransactionRequest( 5120L).setBillingRefNo("1245").setPaymentAmount(100L).setBankCode("2")),
    UPI_QR_Void(new DoTransactionRequest( 5121L).setBillingRefNo("1245").setPaymentAmount(100L).setBatchNo(9023).setRoc(119)),
    UPIStatus(new DoTransactionRequest( 5122L).setBillingRefNo("1245").setPaymentAmount(100L).setBatchNo(9023).setRoc(119)),
    BharatQRSale(new DoTransactionRequest( 5123L).setBillingRefNo("1245").setPaymentAmount(100L).setBankCode("1")),
    ECCSale(25169L),
    ECCVoid(25170L) ;

    private Long value;
    private HeaderRequest<DoTransactionRequest> request;

    TransactionType(Long i) {
        this.value = i;
    }

    TransactionType(DoTransactionRequest doTransactionRequest) {
        request = new HeaderRequest<>(BillingMethodId.DO_TRANSACTION.getValue());
        if (doTransactionRequest.getTransactionType()==4001){
            HashMap<String,String> additionalInfo=new HashMap<>();
            additionalInfo.put("OfficerId","1234");
            additionalInfo.put("Parking","5000");
            additionalInfo.put("Towing","100");
            additionalInfo.put("Wrong Lane","10000");
            doTransactionRequest.setAdditionalInfo(additionalInfo);
        }
        doTransactionRequest.setMobileNumberForEChargeSlip("9582001423");
        request.setDetail(doTransactionRequest);
    }

    public HeaderRequest<DoTransactionRequest> getRequest() {
        return request;
    }

    public Long getValue() {
        return value;
    }

}
