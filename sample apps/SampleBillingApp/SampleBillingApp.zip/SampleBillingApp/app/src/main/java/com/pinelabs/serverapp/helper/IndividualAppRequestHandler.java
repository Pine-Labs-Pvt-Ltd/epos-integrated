package com.pinelabs.serverapp.helper;

/*
 * Created by Kushaal Singla on 5/10/2018.
 */

import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;
import android.support.annotation.NonNull;

import com.pinelabs.serverapp.beans.beans.ParameterJson;
import com.pinelabs.serverapp.beans.responses.ActivationResponse;
import com.pinelabs.serverapp.beans.responses.BaseResponse;
import com.pinelabs.serverapp.beans.responses.GetAppStatusResponse;
import com.pinelabs.serverapp.beans.responses.LoginResponse;
import com.pinelabs.serverapp.enums.OperationType;
import com.pinelabs.serverapp.enums.ResponseStatus;

public class IndividualAppRequestHandler {
    private static IndividualAppRequestHandler instance;

    private IndividualAppRequestHandler() {
    }

    public static IndividualAppRequestHandler getInstance() {
        if (instance == null) {
            synchronized (IndividualAppRequestHandler.class) {
                if (instance == null) {
                    instance = new IndividualAppRequestHandler();
                }
            }
        }
        return instance;
    }

    private void sendResponse(Messenger messenger, int what, @NonNull BaseResponse baseResponse) throws RemoteException {
        if (messenger != null) {
            Message message = Message.obtain(null, what);
            message.setData(baseResponse.getBundle());
            messenger.send(message);

        }
    }

    public void sendBaseResponse(Message msg, int opType, int responseCode, String responseMsg) throws RemoteException {
        BaseResponse baseResponse = new BaseResponse();
        baseResponse.setOperationType(opType);
        baseResponse.setResponseCode(responseCode);
        baseResponse.setResponseMessage(responseMsg);
        sendResponse(msg.replyTo, msg.what, baseResponse);
    }

    public void handleActivationRequest(Message msg) throws RemoteException {
        ActivationResponse activationResponse = new ActivationResponse();
        activationResponse.setOperationType(OperationType.ACTIVATION.getValue());
        activationResponse.setResponseCode(ResponseStatus.SUCCESS.getValue());
        activationResponse.setResponseMessage("Success");
        activationResponse.setClientId(1234);
        activationResponse.setAppVersion("v1.0.1");
        ParameterJson parameterJson = new ParameterJson();
        parameterJson.setFullSerialNumber("L4ACT54959");
        parameterJson.setHardwareId("10000004");
        activationResponse.setParameters(parameterJson);
        sendResponse(msg.replyTo, msg.what, activationResponse);
    }

    public void handleSynchronizationRequest(Message msg) throws RemoteException {
        ActivationResponse activationResponse = new ActivationResponse();
        activationResponse.setOperationType(OperationType.SETTLEMENT.getValue());
        activationResponse.setResponseCode(ResponseStatus.SUCCESS.getValue());
        activationResponse.setResponseMessage("Success");
        activationResponse.setClientId(1234);
        activationResponse.setAppVersion("v1.0.1");

        sendResponse(msg.replyTo, msg.what, activationResponse);
    }

    public void handleGetAppStatusRequest(Message msg) throws RemoteException {
        GetAppStatusResponse getAppStatusResponse = new GetAppStatusResponse();
        getAppStatusResponse.setOperationType(OperationType.GET_APP_STATUS.getValue());
        getAppStatusResponse.setResponseCode(ResponseStatus.SUCCESS.getValue());
        getAppStatusResponse.setResponseMessage("Success");
        getAppStatusResponse.setAppStatus(0);
        getAppStatusResponse.setAppVersion("v1.0.1");

        sendResponse(msg.replyTo, msg.what, getAppStatusResponse);
    }

    public void handleAddUserRequest(Message msg) throws RemoteException {
        sendBaseResponse(msg, OperationType.ADD_USER.getValue(), ResponseStatus.SUCCESS.getValue(), "Success");
    }

    public void handleLoginRequest(Message msg) throws RemoteException {
        LoginResponse loginResponse = new LoginResponse();
        loginResponse.setOperationType(OperationType.LOGIN.getValue());
        loginResponse.setResponseCode(ResponseStatus.SUCCESS.getValue());
        loginResponse.setResponseMessage("Success");
        loginResponse.setUserId("1234");
        sendResponse(msg.replyTo, msg.what, loginResponse);
    }

    public void handleChangePasswordRequest(Message msg) throws RemoteException {
        sendBaseResponse(msg, OperationType.CHANGE_PASSWORD.getValue(), ResponseStatus.SUCCESS.getValue(), "Success");
    }

    public void handleDeleteUserRequest(Message msg) throws RemoteException {
        sendBaseResponse(msg, OperationType.DELETE_USER.getValue(), ResponseStatus.SUCCESS.getValue(), "Success");
    }

    public void handleLaunchAppRequest(Message msg) throws RemoteException {
        sendBaseResponse(msg, OperationType.LAUNCH_APP.getValue(), ResponseStatus.SUCCESS.getValue(), "Success");
    }

    public void handleLaunchAppConfigRequest(Message msg) throws RemoteException {
        sendBaseResponse(msg, OperationType.LAUNCH_APP_CONFIG.getValue(), ResponseStatus.SUCCESS.getValue(), "Success");
    }
}
