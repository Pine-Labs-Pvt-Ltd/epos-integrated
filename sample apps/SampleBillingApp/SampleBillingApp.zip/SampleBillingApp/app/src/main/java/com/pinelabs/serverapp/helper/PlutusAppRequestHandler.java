package com.pinelabs.serverapp.helper;

/*
 * Created by Kushaal Singla on 5/10/2018.
 */

import android.os.Bundle;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;
import android.text.TextUtils;

import com.google.gson.Gson;
import com.pinelabs.serverapp.beans.beans.ParameterJson;
import com.pinelabs.serverapp.beans.requests.BaseRequest;
import com.pinelabs.serverapp.beans.requests.ChangePasswordRequest;
import com.pinelabs.serverapp.beans.requests.LoginRequest;
import com.pinelabs.serverapp.beans.responses.ActivationResponse;
import com.pinelabs.serverapp.beans.responses.BaseResponse;
import com.pinelabs.serverapp.beans.responses.GetAppStatusResponse;
import com.pinelabs.serverapp.beans.responses.LoginResponse;
import com.pinelabs.serverapp.config.AppConfig;
import com.pinelabs.serverapp.enums.OperationType;
import com.pinelabs.serverapp.enums.PlutusOperationType;
import com.pinelabs.serverapp.enums.ResponseStatus;
import com.pinelabs.serverapp.utils.GsonUtils;
import com.pinelabs.serverapp.utils.PlutusUtils;

import java.util.Arrays;

public class PlutusAppRequestHandler {
    private static PlutusAppRequestHandler instance;

    private PlutusAppRequestHandler() {
    }

    public static PlutusAppRequestHandler getInstance() {
        if (instance == null) {
            synchronized (IndividualAppRequestHandler.class) {
                if (instance == null) {
                    instance = new PlutusAppRequestHandler();
                }
            }
        }
        return instance;
    }

    private void sendResponse(Messenger messenger, int what, byte[] byteArr) throws RemoteException {
        if (messenger != null) {
            Message message = Message.obtain(null, what);
            Bundle bundle = new Bundle();
            bundle.putByteArray(AppConfig.PLUTUS_RESPONSE_KEY, byteArr);
            message.setData(bundle);
            messenger.send(message);

        }
    }

    public void sendBaseResponse(Message msg, byte[] sourceId, byte funcCode, int responseCode, String responseMsg, int opType) throws RemoteException {
        BaseResponse baseResponse = new BaseResponse();
        baseResponse.setOperationType(opType);
        baseResponse.setResponseCode(responseCode);
        baseResponse.setResponseMessage(responseMsg);
        byte[] bytes = PlutusUtils.GetTransmissionPacketForCentral(sourceId, funcCode, GsonUtils.fromJsonToString(baseResponse));
        sendResponse(msg.replyTo, msg.what, bytes);
    }

    public void handleActivationRequest(Message msg, byte[] sourceId) throws RemoteException {
        ActivationResponse activationResponse = new ActivationResponse();
        activationResponse.setOperationType(PlutusOperationType.ACTIVATION.getValue());
        activationResponse.setResponseCode(ResponseStatus.SUCCESS.getValue());
        activationResponse.setResponseMessage("Success");
        activationResponse.setClientId(1234);
        activationResponse.setAppVersion("v1.0.1");
        ParameterJson parameterJson = new ParameterJson();
        parameterJson.setFullSerialNumber("L4ACT54959");
        parameterJson.setHardwareId("10000004");
        activationResponse.setParameters(parameterJson);
        byte[] bytes = PlutusUtils.GetTransmissionPacketForCentral(sourceId, PlutusOperationType.ACTIVATION.getValue(), GsonUtils.fromJsonToString(activationResponse));
        sendResponse(msg.replyTo, msg.what, bytes);
    }

    public void handleSynchronizationRequest(Message msg, byte[] sourceId) throws RemoteException {
        ActivationResponse activationResponse = new ActivationResponse();
        activationResponse.setOperationType(PlutusOperationType.SETTLEMENT.getValue());
        activationResponse.setResponseCode(ResponseStatus.SUCCESS.getValue());
        activationResponse.setResponseMessage("Success");
        activationResponse.setClientId(1234);
        activationResponse.setAppVersion("v1.0.1");

        byte[] bytes = PlutusUtils.GetTransmissionPacketForCentral(sourceId, PlutusOperationType.SETTLEMENT.getValue(), GsonUtils.fromJsonToString(activationResponse));
        sendResponse(msg.replyTo, msg.what, bytes);
    }

    public void handleGetAppStatusRequest(Message msg, byte[] sourceId) throws RemoteException {
        GetAppStatusResponse getAppStatusResponse = new GetAppStatusResponse();
        getAppStatusResponse.setOperationType(PlutusOperationType.GET_APP_STATUS.getValue());
        getAppStatusResponse.setResponseCode(ResponseStatus.SUCCESS.getValue());
        getAppStatusResponse.setResponseMessage("Success");
        getAppStatusResponse.setAppStatus(0);
        getAppStatusResponse.setAppVersion("v1.0.1");

        byte[] bytes = PlutusUtils.GetTransmissionPacketForCentral(sourceId, PlutusOperationType.GET_APP_STATUS.getValue(), GsonUtils.fromJsonToString(getAppStatusResponse));
        sendResponse(msg.replyTo, msg.what, bytes);
    }

    public void handleAddUserRequest(Message msg, byte[] sourceId) throws RemoteException {

        if (isValidUser(getResponseString(msg))) {
            sendBaseResponse(msg, sourceId, PlutusOperationType.ADD_USER.getValue(), ResponseStatus.SUCCESS.getValue(), "User created successfully", OperationType.ADD_USER.getValue());
        } else {
            sendBaseResponse(msg, sourceId, PlutusOperationType.ADD_USER.getValue(), ResponseStatus.FAILED.getValue(), "Could not create new user", OperationType.ADD_USER.getValue());
        }

    }

    public void handleLoginRequest(Message msg, byte[] sourceId, byte opType) throws RemoteException {

        if (isValidLoginUser(getResponseString(msg))) {
            LoginResponse loginResponse = new LoginResponse();
            loginResponse.setOperationType(OperationType.LOGIN.getValue());
            loginResponse.setResponseCode(ResponseStatus.SUCCESS.getValue());
            loginResponse.setResponseMessage("Success");
            loginResponse.setUserId("1234");
            byte[] bytes = PlutusUtils.GetTransmissionPacketForCentral(sourceId, PlutusOperationType.LOGIN.getValue(), GsonUtils.fromJsonToString(loginResponse));
            sendResponse(msg.replyTo, msg.what, bytes);
        } else {
            sendBaseResponse(msg, sourceId, opType, ResponseStatus.FAILED.getValue(), "Invalid user", OperationType.LOGIN.getValue());
        }
    }

    public void handleChangePasswordRequest(Message msg, byte[] sourceId) throws RemoteException {
        if (isValidChangePasswordRequest(getResponseString(msg))) {
            sendBaseResponse(msg, sourceId, PlutusOperationType.CHANGE_PASSWORD.getValue(), ResponseStatus.SUCCESS.getValue(), "Success", OperationType.CHANGE_PASSWORD.getValue());
        } else {
            sendBaseResponse(msg, sourceId, PlutusOperationType.CHANGE_PASSWORD.getValue(), ResponseStatus.FAILED.getValue(), "Old password is incorrect", OperationType.CHANGE_PASSWORD.getValue());
        }
    }

    public void handleDeleteUserRequest(Message msg, byte[] sourceId) throws RemoteException {
        if (isValidUser(getResponseString(msg))) {
            sendBaseResponse(msg, sourceId, PlutusOperationType.DELETE_USER.getValue(), ResponseStatus.SUCCESS.getValue(), "User deleted successfully", OperationType.DELETE_USER.getValue());
        } else {
            sendBaseResponse(msg, sourceId, PlutusOperationType.DELETE_USER.getValue(), ResponseStatus.FAILED.getValue(), "Could not delete user", OperationType.DELETE_USER.getValue());
        }
    }

    private boolean isValidChangePasswordRequest(String response) {
        try {
            if (!TextUtils.isEmpty(response)) {
                Gson gson = new Gson();
                ChangePasswordRequest request = gson.fromJson(response, ChangePasswordRequest.class);
                if (request.getCurrentPin().equals("abcd")) {
                    return true;
                }
            }

        } catch (Exception ex) {
        }
        return false;
    }

    private boolean isValidLoginUser(String response) {
        try {
            if (!TextUtils.isEmpty(response)) {
                Gson gson = new Gson();
                LoginRequest request = gson.fromJson(response, LoginRequest.class);
                if (request.getUserId().equals("1234") && request.getUserPin().equals("1234")) {
                    return true;
                }
            }

        } catch (Exception ex) {
        }
        return false;
    }

    private boolean isValidUser(String request) {
        try {
            if (!TextUtils.isEmpty(request)) {
                Gson gson = new Gson();
                BaseRequest baseRequest = gson.fromJson(request, BaseRequest.class);
                if (baseRequest.getUserId().equals("1234")) {
                    return false;
                } else {
                    return true;
                }
            }

        } catch (Exception ex) {
        }
        return false;

    }

    private String getResponseString(Message msg) {
        Bundle bundle = msg.getData();
        if (bundle != null) {

            byte[] data = bundle.getByteArray(AppConfig.REQUEST_KEY);
            if (data != null) {
                byte[] arr2 = Arrays.copyOfRange(data, 6, data.length - 1);
                return new String(arr2);
            }

        }
        return null;
    }
}
