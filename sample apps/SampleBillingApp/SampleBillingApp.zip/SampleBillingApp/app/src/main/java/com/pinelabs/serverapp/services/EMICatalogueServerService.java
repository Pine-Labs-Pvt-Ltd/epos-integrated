package com.pinelabs.serverapp.services;

import android.app.Service;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;
import android.support.annotation.Nullable;

import com.pinelabs.serverapp.helper.IndividualAppRequestHandler;
import com.pinelabs.serverapp.beans.requests.BaseRequest;
import com.pinelabs.serverapp.config.AppConfig;
import com.pinelabs.serverapp.enums.OperationType;
import com.pinelabs.serverapp.enums.ResponseStatus;
import com.pinelabs.serverapp.utils.GsonUtils;



/*
 * Created by Kushaal Singla on 4/5/2018.
 */

public class EMICatalogueServerService extends Service {
    final Messenger mMessenger = new Messenger(new IncomingHandler());

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return mMessenger.getBinder();
    }

    private void processMasterAppRequest(Message msg) {
        Bundle bundle = msg.getData();
        String requestDataValue = bundle.getString(AppConfig.REQUEST_KEY); // Json String
        //Read Json String to identify the API request and perform action.
        BaseRequest baseRequest = GsonUtils.fromStringToJson(requestDataValue, BaseRequest.class);
        try {
            if (baseRequest != null) {
                int opType = baseRequest.getOperationType();
                if (OperationType.isExists(opType)) {
                    handleRequest(opType, baseRequest, msg);
                } else {
                    IndividualAppRequestHandler.getInstance().sendBaseResponse(msg, opType, ResponseStatus.FAILED.getValue(), "No Such operation code exists");
                }
            } else {
                IndividualAppRequestHandler.getInstance().sendBaseResponse(msg, -1, ResponseStatus.FAILED.getValue(), "Failed");
            }
            //Sending Msg
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }

    private void handleRequest(int opType, BaseRequest baseRequest, Message msg) throws RemoteException {
        if (opType == OperationType.ACTIVATION.getValue()) {
            IndividualAppRequestHandler.getInstance().handleActivationRequest(msg);
        } else if (opType == OperationType.SETTLEMENT.getValue()) {
            IndividualAppRequestHandler.getInstance().handleSynchronizationRequest(msg);
        } else if (opType == OperationType.GET_APP_STATUS.getValue()) {
            IndividualAppRequestHandler.getInstance().handleGetAppStatusRequest(msg);
        } else if (opType == OperationType.LOGIN.getValue()) {
            IndividualAppRequestHandler.getInstance().handleLoginRequest(msg);
        } else if (opType == OperationType.CHANGE_PASSWORD.getValue()) {
            IndividualAppRequestHandler.getInstance().handleChangePasswordRequest(msg);
        } else if (opType == OperationType.ADD_USER.getValue()) {
            IndividualAppRequestHandler.getInstance().handleAddUserRequest(msg);
        } else if (opType == OperationType.DELETE_USER.getValue()) {
            IndividualAppRequestHandler.getInstance().handleDeleteUserRequest(msg);
        } else if (opType == OperationType.LAUNCH_APP.getValue()) {
            IndividualAppRequestHandler.getInstance().handleLaunchAppRequest(msg);
        } else if (opType == OperationType.LAUNCH_APP_CONFIG.getValue()) {
            IndividualAppRequestHandler.getInstance().handleLaunchAppConfigRequest(msg);
        }
    }


    private boolean isValidRequest(Message msg) {
        return true;
    }

    private class IncomingHandler extends Handler {
        @Override
        public void handleMessage(Message msg) {
            if (isValidRequest(msg)) {
                processMasterAppRequest(msg);
            } else {
                super.handleMessage(msg);
            }
        }
    }
}
