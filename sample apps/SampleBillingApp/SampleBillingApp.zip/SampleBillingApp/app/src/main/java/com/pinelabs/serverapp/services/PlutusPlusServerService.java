package com.pinelabs.serverapp.services;

import android.app.Service;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;
import android.support.annotation.Nullable;

import com.pinelabs.serverapp.config.AppConfig;
import com.pinelabs.serverapp.enums.PlutusOperationType;
import com.pinelabs.serverapp.enums.ResponseStatus;
import com.pinelabs.serverapp.helper.PlutusAppRequestHandler;



/*
 * Created by Kushaal Singla on 4/5/2018.
 */

public class PlutusPlusServerService extends Service {
    final Messenger mMessenger = new Messenger(new IncomingHandler());

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return mMessenger.getBinder();
    }

    private void processMasterAppRequest(Message msg) {
        Bundle bundle = msg.getData();
        byte[] byteArray = bundle.getByteArray(AppConfig.PLUTUS_REQUEST_KEY); // Json String
        //Read Json String to identify the API request and perform action.
        try {
            byte[] sourceId = new byte[]{0x00, 0x00};
            if (byteArray != null && byteArray.length > 4) {
                byte opType = byteArray[3];
                System.arraycopy(byteArray, 0, sourceId, 0, 2);
                if (PlutusOperationType.isExists(opType)) {
                    handleRequest(opType, sourceId, msg);
                } else {
                    PlutusAppRequestHandler.getInstance().sendBaseResponse(msg, sourceId, opType, ResponseStatus.FAILED.getValue(), "No Such operation code exists",0);
                }
            } else {
                PlutusAppRequestHandler.getInstance().sendBaseResponse(msg, sourceId, (byte) 0x00, ResponseStatus.FAILED.getValue(), "Failed",0);
            }
            //Sending Msg
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }

    private void handleRequest(byte opType, byte[] sourceId, Message msg) throws RemoteException {
        if (opType == PlutusOperationType.ACTIVATION.getValue()) {
            PlutusAppRequestHandler.getInstance().handleActivationRequest(msg, sourceId);
        } else if (opType == PlutusOperationType.SETTLEMENT.getValue()) {
            PlutusAppRequestHandler.getInstance().handleSynchronizationRequest(msg, sourceId);
        } else if (opType == PlutusOperationType.GET_APP_STATUS.getValue()) {
            PlutusAppRequestHandler.getInstance().handleGetAppStatusRequest(msg, sourceId);
        } else if (opType == PlutusOperationType.LOGIN.getValue()) {
            PlutusAppRequestHandler.getInstance().handleLoginRequest(msg, sourceId, opType);
        } else if (opType == PlutusOperationType.CHANGE_PASSWORD.getValue()) {
            PlutusAppRequestHandler.getInstance().handleChangePasswordRequest(msg, sourceId);
        } else if (opType == PlutusOperationType.ADD_USER.getValue()) {
            PlutusAppRequestHandler.getInstance().handleAddUserRequest(msg, sourceId);
        } else if (opType == PlutusOperationType.DELETE_USER.getValue()) {
            PlutusAppRequestHandler.getInstance().handleDeleteUserRequest(msg, sourceId);
        }  else if (opType == PlutusOperationType.SET_CONNECTION.getValue()) {
            PlutusAppRequestHandler.getInstance().handleSynchronizationRequest(msg, sourceId);
        }else {
            PlutusAppRequestHandler.getInstance().sendBaseResponse(msg, sourceId, opType, ResponseStatus.FAILED.getValue(), "Not Implemented",0);
        }
    }

    private boolean isValidRequest(Message msg) {
        return true;
    }

    private class IncomingHandler extends Handler {
        @Override
        public void handleMessage(Message msg) {
            if (isValidRequest(msg)) {
                processMasterAppRequest(msg);
            } else {
                super.handleMessage(msg);
            }
        }
    }
}
