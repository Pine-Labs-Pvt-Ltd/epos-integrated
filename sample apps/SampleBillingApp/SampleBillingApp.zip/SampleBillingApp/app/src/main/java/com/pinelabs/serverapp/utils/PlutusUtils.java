package com.pinelabs.serverapp.utils;

/*
 * Created by Kushaal Singla on 5/10/2018.
 */

public class PlutusUtils {
    public static byte[] GetTransmissionPacketForCentral(byte[] sourceId, byte opType, String jsonStringData) {
        int iOffset = 0;
        byte[] msgBytes = jsonStringData.getBytes();
        int iCSVLen = msgBytes.length;
        int finalMsgLen = iCSVLen + 7;
        // 7 = 2 byte source , 2 byte function code, 2 byte length, 1 byte termination
        byte[] msgBytesExtra = new byte[finalMsgLen];
        //source id-2 bytes
        msgBytesExtra[iOffset] = sourceId[0];
        iOffset++;
        msgBytesExtra[iOffset] = sourceId[1];
        iOffset++;

        //function code or MTI-2 bytes
        msgBytesExtra[iOffset] = 0x19;
        iOffset++;
        msgBytesExtra[iOffset] = opType;
        iOffset++;
        //data length to follow
        msgBytesExtra[iOffset] = (byte) ((byte) (iCSVLen >> 8) & 0xFF);
        iOffset++;
        msgBytesExtra[iOffset] = (byte) (iCSVLen & 0xFF);
        iOffset++;
        //
        System.arraycopy(msgBytes, 0, msgBytesExtra, iOffset, msgBytes.length);
        iOffset += msgBytes.length;
        msgBytesExtra[iOffset] = (byte) 0xFF;

        //function code or MTI-2 bytes
        msgBytesExtra[iOffset] = (byte) 0xFF;
        iOffset++;

        return msgBytesExtra;
    }

}
